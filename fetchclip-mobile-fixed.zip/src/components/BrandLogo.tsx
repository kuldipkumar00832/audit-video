interface BrandLogoProps {
  className?: string;
}

export function BrandLogo({ className = 'w-7 h-7' }: BrandLogoProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 32 32"
      fill="none"
      className={`${className} shrink-0`}
      aria-hidden="true"
    >
      <rect width="32" height="32" rx="8" fill="#2563EB" />
      <path
        d="M6.5 10.5V7.8A1.3 1.3 0 0 1 7.8 6.5h2.7M21.5 6.5h2.7a1.3 1.3 0 0 1 1.3 1.3v2.7M25.5 21.5v2.7a1.3 1.3 0 0 1-1.3 1.3h-2.7M10.5 25.5H7.8a1.3 1.3 0 0 1-1.3-1.3v-2.7"
        stroke="#93C5FD"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12.8 11.1v9.8a.65.65 0 0 0 1 .54l7.8-4.9a.65.65 0 0 0 0-1.08l-7.8-4.9a.65.65 0 0 0-1 .54Z"
        fill="#FFFFFF"
      />
    </svg>
  );
}
