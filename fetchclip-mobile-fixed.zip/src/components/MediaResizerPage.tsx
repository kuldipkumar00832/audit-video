import { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowDownToLine,
  ArrowUp,
  Check,
  ChevronDown,
  Crop,
  FileDown,
  FileUp,
  Loader2,
  SlidersHorizontal,
  Upload,
} from 'lucide-react';
import type {
  AspectRatioOption,
  ProbedResizeUpload,
  QualityPreset,
  ResizedMediaResult,
} from '../types/media';
import { BrandLogo } from './BrandLogo';

interface MediaResizerPageProps {
  fileInputRef: React.RefObject<HTMLInputElement | null>;
  onNavigateDownloader: () => void;
  onNavigateWatermark: () => void;
}

const ASPECT_OPTIONS: Array<{ id: AspectRatioOption; label: string }> = [
  { id: 'original', label: 'Original' },
  { id: '16:9', label: '16:9' },
  { id: '9:16', label: '9:16' },
  { id: '1:1', label: '1:1' },
  { id: '4:5', label: '4:5' },
  { id: '4:3', label: '4:3' },
];

const AUDIO_CLARITY_PRESETS: Array<{ id: string; label: string; value: number }> = [
  { id: 'original', label: 'Original', value: 0 },
  { id: 'clean', label: 'Clean', value: 40 },
  { id: 'studio', label: 'Studio', value: 75 },
  { id: 'max', label: 'Max Fix', value: 100 },
];

const QUALITY_OPTIONS: Array<{ id: QualityPreset; label: string }> = [
  { id: 'balanced', label: 'Balanced' },
  { id: 'high', label: 'High' },
  { id: 'maximum', label: 'Maximum' },
];

const FEATURE_CARDS = [
  {
    title: 'Reduce File Size (KB / MB)',
    formats: 'Shrink down to 2 KB – 4 KB',
    note: 'Compress heavy multi-megabyte videos and images down to exact KB or lower MB targets.',
    icon: FileDown,
  },
  {
    title: 'Increase File Size (KB / MB)',
    formats: 'Scale up to 40 MB – 50 MB',
    note: 'Raise small KB or low-MB videos and photos up to 40–50 MB with valid container formatting.',
    icon: FileUp,
  },
  {
    title: 'Aspect Ratio & Dimensions',
    formats: 'Original · 16:9 · 9:16 · 1:1 · 4:5 · 4:3',
    note: 'Change aspect ratio and adjust pixel scale smoothly for any social feed or portal.',
    icon: Crop,
  },
  {
    title: 'Output Quality Control',
    formats: 'Balanced · High · Maximum',
    note: 'Pick encoding quality while keeping your chosen target size and dimensions on point.',
    icon: SlidersHorizontal,
  },
];

const CAPABILITIES = [
  {
    num: '01',
    title: 'Full KB-to-MB Bidirectional Control',
    description:
      'Whether you need to shrink a large photo or clip down to 2 KB–4 KB for strict portal forms or expand a small file up to 40–50 MB, switch cleanly between KB and MB.',
    span: 'md:col-span-2',
  },
  {
    num: '02',
    title: 'Smart Aspect Ratio Cropping',
    description:
      'Switch cleanly between 16:9 widescreen, 9:16 Reels, 1:1 square, 4:5 portrait, 4:3 standard, or keep your original proportions with zero black bars.',
    span: 'md:col-span-1',
  },
  {
    num: '03',
    title: 'Studio Voice & Noise Restoration',
    description:
      'Fix distorted, clipped, or noisy video audio—remove background hum, hiss, and crackle while restoring crisp, clean studio vocal clarity.',
    span: 'md:col-span-1',
  },
  {
    num: '04',
    title: 'Fast Re-Processing Without Re-Uploading',
    description:
      'Upload once, adjust your aspect ratio, voice clarity level, target KB/MB, or quality as many times as needed, preview the result, and download on the first click.',
    span: 'md:col-span-2',
  },
];

const STEPS = [
  {
    number: '01',
    title: 'Upload a video or image',
    description:
      'Select or drop any video or image from your device to inspect its current KB/MB size, dimensions, and aspect ratio.',
  },
  {
    number: '02',
    title: 'Set ratio, voice clarity, target KB/MB, and quality',
    description:
      'Choose an aspect ratio, adjust voice noise reduction and clarity from 0% to 100%, pick KB or MB (from 2 KB up to 50 MB), and select output quality.',
  },
  {
    number: '03',
    title: 'Resize and download',
    description:
      'Click Resize Media to generate your updated file, preview the cleaned voice and exact output size, and download immediately.',
  },
];

const FAQS = [
  {
    q: 'Can I both decrease to a few KB and increase up to 50 MB?',
    a: 'Yes. Switch between KB and MB or drag the slider anywhere from 2 KB up to 50 MB (or higher for larger uploads) to shrink files down or scale small files up cleanly.',
  },
  {
    q: 'Can this clean up noisy, distorted, or low-quality video voice audio?',
    a: 'Yes. Use the Voice & Audio Clarity slider (0%–100%) or presets (Clean, Studio, Max Fix) to repair clipped peaks, strip background room noise and hiss, and balance speech into clean studio-grade audio.',
  },
  {
    q: 'What happens when I change the aspect ratio?',
    a: 'When you switch to a ratio such as 16:9, 9:16, 1:1, 4:5, or 4:3, the media is center-cropped cleanly to match the chosen proportions with zero black bars.',
  },
  {
    q: 'Do I have to re-upload the file to test a different KB/MB, ratio, or voice setting?',
    a: 'No. Once your video or image is uploaded, you can adjust the aspect ratio, voice clarity, target KB/MB, or quality and click Resize Media again without re-uploading.',
  },
];

function computePreviewDimensions(
  srcW: number,
  srcH: number,
  aspect: AspectRatioOption,
  scalePercent: number
): { w: number; h: number } {
  const ratioMap: Record<Exclude<AspectRatioOption, 'original'>, number> = {
    '16:9': 16 / 9,
    '9:16': 9 / 16,
    '1:1': 1,
    '4:5': 4 / 5,
    '4:3': 4 / 3,
  };
  let baseW = srcW;
  let baseH = srcH;
  if (aspect !== 'original') {
    const targetRatio = ratioMap[aspect];
    if (srcW / srcH > targetRatio) {
      baseH = srcH;
      baseW = Math.round(srcH * targetRatio);
    } else {
      baseW = srcW;
      baseH = Math.round(srcW / targetRatio);
    }
  }
  const factor = scalePercent / 100;
  return {
    w: Math.max(16, Math.floor((baseW * factor) / 2) * 2),
    h: Math.max(16, Math.floor((baseH * factor) / 2) * 2),
  };
}

const MIN_TARGET_KB = 2;
const DEFAULT_MAX_KB = 50 * 1024; // 50 MB

function formatTargetSize(kb: number): string {
  if (kb >= 1024) {
    const mb = kb / 1024;
    return `${mb >= 10 ? mb.toFixed(1) : mb.toFixed(2)} MB`;
  }
  return `${Math.round(kb)} KB`;
}

function kbToSliderPos(kb: number, maxKb: number): number {
  const clamped = Math.min(maxKb, Math.max(MIN_TARGET_KB, kb));
  const ratio = Math.log(clamped / MIN_TARGET_KB) / Math.log(maxKb / MIN_TARGET_KB);
  return Math.round(ratio * 1000);
}

function sliderPosToKb(pos: number, maxKb: number): number {
  const t = Math.min(1, Math.max(0, pos / 1000));
  const rawKb = MIN_TARGET_KB * Math.pow(maxKb / MIN_TARGET_KB, t);
  if (rawKb < 20) return Math.max(MIN_TARGET_KB, Math.round(rawKb));
  if (rawKb < 200) return Math.round(rawKb / 5) * 5;
  if (rawKb < 1024) return Math.round(rawKb / 10) * 10;
  const mb = rawKb / 1024;
  if (mb < 10) return Math.round(mb * 10) * 102.4;
  return Math.round(mb) * 1024;
}

export function MediaResizerPage({
  fileInputRef,
  onNavigateDownloader,
  onNavigateWatermark,
}: MediaResizerPageProps) {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedName, setSelectedName] = useState<string | null>(null);
  const [localPreviewUrl, setLocalPreviewUrl] = useState<string | null>(null);
  const [probed, setProbed] = useState<ProbedResizeUpload | null>(null);

  const [aspectRatio, setAspectRatio] = useState<AspectRatioOption>('original');
  const [audioClarity, setAudioClarity] = useState<number>(0);
  const [sizeUnit, setSizeUnit] = useState<'KB' | 'MB'>('MB');
  const [targetSizeInput, setTargetSizeInput] = useState<string>('2.0');
  const [quality, setQuality] = useState<QualityPreset>('high');

  const [resizing, setResizing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ResizedMediaResult | null>(null);

  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [downloaded, setDownloaded] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const activeXhrRef = useRef<XMLHttpRequest | null>(null);
  const localPreviewRef = useRef<string | null>(null);

  useEffect(() => {
    return () => {
      if (localPreviewRef.current) {
        URL.revokeObjectURL(localPreviewRef.current);
        localPreviewRef.current = null;
      }
    };
  }, []);

  const parsedTargetKb = useMemo(() => {
    const n = Number(targetSizeInput);
    if (!Number.isFinite(n) || n <= 0) return MIN_TARGET_KB;
    const kb = sizeUnit === 'MB' ? n * 1024 : n;
    return Math.min(200 * 1024, Math.max(MIN_TARGET_KB, kb));
  }, [targetSizeInput, sizeUnit]);

  const sliderMaxKb = useMemo(() => {
    if (!probed) return DEFAULT_MAX_KB;
    return Math.max(DEFAULT_MAX_KB, Math.min(200 * 1024, Math.ceil(probed.sizeKb * 2)));
  }, [probed]);

  const sliderPos = useMemo(
    () => kbToSliderPos(parsedTargetKb, sliderMaxKb),
    [parsedTargetKb, sliderMaxKb]
  );

  const previewDims = useMemo(() => {
    if (!probed) return null;
    return computePreviewDimensions(probed.width, probed.height, aspectRatio, 100);
  }, [probed, aspectRatio]);

  function triggerFilePicker() {
    fileInputRef.current?.click();
  }

  function handleFileUpload(file: File) {
    const isMedia =
      file.type.startsWith('video/') ||
      file.type.startsWith('image/') ||
      /\.(mp4|webm|mov|m4v|mkv|avi|png|jpe?g|webp|bmp)$/i.test(file.name);

    if (!isMedia) {
      setError('Please choose a valid video or image file.');
      return;
    }

    if (file.size > 200 * 1024 * 1024) {
      setError('File size must be 200 MB or smaller.');
      return;
    }

    activeXhrRef.current?.abort();
    if (localPreviewRef.current) {
      URL.revokeObjectURL(localPreviewRef.current);
    }
    const nextObjectUrl = URL.createObjectURL(file);
    localPreviewRef.current = nextObjectUrl;
    setLocalPreviewUrl(nextObjectUrl);

    setError(null);
    setResult(null);
    setDownloaded(false);
    setSelectedName(file.name);
    setUploading(true);
    setUploadProgress(0);

    const xhr = new XMLHttpRequest();
    activeXhrRef.current = xhr;

    xhr.open('POST', '/api/resize-upload', true);
    xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
    xhr.setRequestHeader('X-File-Name', encodeURIComponent(file.name));

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && event.total > 0) {
        setUploadProgress(Math.min(100, Math.round((event.loaded / event.total) * 100)));
      }
    };

    xhr.onload = () => {
      setUploading(false);
      try {
        const data = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300) {
          const info = data as ProbedResizeUpload;
          setProbed(info);
          setAspectRatio('original');
          setAudioClarity(0);
          if (info.sizeBytes < 1024 * 1024) {
            setSizeUnit('KB');
            setTargetSizeInput(String(Math.max(MIN_TARGET_KB, Math.round(info.sizeKb))));
          } else {
            setSizeUnit('MB');
            setTargetSizeInput(String(Number(info.sizeMb.toFixed(2))));
          }
        } else {
          setError(data?.error || 'Could not inspect this media file.');
        }
      } catch {
        setError('Unexpected response while reading your file.');
      }
    };

    xhr.onerror = () => {
      setUploading(false);
      setError('Upload failed. Please try again.');
    };

    xhr.onabort = () => {
      setUploading(false);
    };

    xhr.send(file);
  }

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) handleFileUpload(file);
    e.target.value = '';
  }

  function handleDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFileUpload(file);
  }

  function handleUnitSwitch(nextUnit: 'KB' | 'MB') {
    if (nextUnit === sizeUnit) return;
    setSizeUnit(nextUnit);
    if (nextUnit === 'KB') {
      setTargetSizeInput(String(Math.max(MIN_TARGET_KB, Math.round(parsedTargetKb))));
    } else {
      const mbVal = parsedTargetKb / 1024;
      setTargetSizeInput(String(mbVal >= 1 ? Number(mbVal.toFixed(2)) : Number(mbVal.toFixed(3))));
    }
  }

  function handleSliderChange(posValue: string) {
    const kb = sliderPosToKb(Number(posValue), sliderMaxKb);
    if (kb >= 1024) {
      setSizeUnit('MB');
      const mb = kb / 1024;
      setTargetSizeInput(String(mb >= 10 ? Number(mb.toFixed(1)) : Number(mb.toFixed(2))));
    } else {
      setSizeUnit('KB');
      setTargetSizeInput(String(Math.max(MIN_TARGET_KB, Math.round(kb))));
    }
  }

  async function handleResizeSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!probed || resizing) return;

    setError(null);
    setResizing(true);
    setDownloaded(false);

    try {
      const response = await fetch('/api/resize-process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uploadToken: probed.uploadToken,
          aspectRatio,
          scalePercent: 100,
          audioClarity,
          targetKb: parsedTargetKb,
          targetMb: Number((parsedTargetKb / 1024).toFixed(4)),
          quality,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || 'Unable to resize this media file.');
      }
      setResult(data as ResizedMediaResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to resize this media file.');
    } finally {
      setResizing(false);
    }
  }

  async function handleDownloadResized() {
    if (!result || downloading) return;
    setError(null);
    setDownloading(true);
    setDownloadProgress(0);
    setDownloaded(false);

    try {
      const response = await fetch(result.downloadUrl, { cache: 'no-store' });
      if (!response.ok) {
        let message = 'Unable to download the resized file. Please resize again.';
        try {
          const errJson = await response.json();
          if (errJson?.error) message = errJson.error;
        } catch {
          // Ignore non-JSON body
        }
        throw new Error(message);
      }

      const contentLength = Number(response.headers.get('content-length') || result.sizeBytes || 0);
      let blob: Blob;

      if (response.body) {
        const reader = response.body.getReader();
        const chunks: Uint8Array<ArrayBuffer>[] = [];
        let received = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            const copy = new Uint8Array(value.byteLength);
            copy.set(value);
            chunks.push(copy);
            received += value.byteLength;
            if (contentLength > 0) {
              setDownloadProgress(Math.min(100, Math.round((received / contentLength) * 100)));
            }
          }
        }

        if (received === 0) {
          throw new Error('Downloaded file was empty. Please try again.');
        }

        blob = new Blob(chunks, { type: result.mimeType });
      } else {
        blob = await response.blob();
        if (blob.size === 0) {
          throw new Error('Downloaded file was empty. Please try again.');
        }
      }

      const blobUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = blobUrl;
      anchor.download = result.outputFilename;
      anchor.style.display = 'none';
      document.body.appendChild(anchor);
      anchor.click();

      window.setTimeout(() => {
        if (anchor.parentNode) {
          anchor.parentNode.removeChild(anchor);
        }
      }, 1000);

      window.setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
      }, 60000);

      setDownloaded(true);
      window.setTimeout(() => {
        setDownloaded(false);
      }, 2600);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Download failed. Please try again.');
    } finally {
      setDownloading(false);
      setDownloadProgress(null);
    }
  }

  const sizeDirectionText = useMemo(() => {
    if (!probed) return '';
    if (Math.abs(parsedTargetKb - probed.sizeKb) < Math.max(1, probed.sizeKb * 0.02)) {
      return `Matches current size (${probed.sizeLabel})`;
    }
    if (parsedTargetKb < probed.sizeKb) {
      return `Reduce from ${probed.sizeLabel} to ~${formatTargetSize(parsedTargetKb)}`;
    }
    return `Increase from ${probed.sizeLabel} to ~${formatTargetSize(parsedTargetKb)}`;
  }, [probed, parsedTargetKb]);

  return (
    <>
      {/* Hero & Media Resizer Workspace */}
      <section id="resizer-tool" className="pt-10 pb-14 sm:pt-14 sm:pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-10">
            <p className="text-xs sm:text-sm font-medium text-blue-600 mb-3 tracking-wide">
              Video & Image Size Resizer
            </p>
            <h1
              className="font-display font-bold tracking-tight text-zinc-950 leading-[1.1] mb-4"
              style={{ fontSize: 'clamp(2.1rem, 4.4vw, 3.35rem)', textWrap: 'balance' }}
            >
              Resize video or image size. Adjust KB, MB, and ratio.
            </h1>
            <p className="text-base sm:text-lg text-zinc-600 leading-relaxed max-w-xl mx-auto">
              Upload any video or image to decrease its size down to a few KB or increase it up to
              50 MB, change its aspect ratio, clean noisy voice audio into studio quality, and pick
              your output quality.
            </p>
          </div>

          {/* Main Workspace Card */}
          <div className="bg-white border border-zinc-200 rounded-2xl p-4 sm:p-6 shadow-sm">
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*,image/*"
              onChange={handleInputChange}
              className="sr-only"
              aria-label="Upload video or image file to resize"
            />

            {/* Upload Dropzone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                if (!uploading && !resizing) setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={handleDrop}
              className={`rounded-xl border-2 border-dashed p-5 sm:p-6 text-center transition-colors ${
                dragActive
                  ? 'border-blue-600 bg-blue-50/60'
                  : 'border-zinc-200 bg-[#FAFAFB] hover:border-zinc-300'
              }`}
            >
              <div className={probed && !uploading ? 'w-full' : 'max-w-md mx-auto flex flex-col items-center'}>
                {uploading ? (
                  <div className="w-full space-y-2.5 py-2">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                      <Loader2 className="w-5 h-5 animate-spin" aria-hidden="true" />
                    </div>
                    <p className="font-display text-base font-bold text-zinc-950">
                      Uploading file ({uploadProgress}%)
                    </p>
                    {selectedName && (
                      <p className="text-xs text-zinc-500 truncate">{selectedName}</p>
                    )}
                    <div className="w-full h-2 bg-zinc-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600 transition-all duration-150"
                        style={{ width: `${Math.max(8, uploadProgress)}%` }}
                      />
                    </div>
                  </div>
                ) : probed ? (
                  <div className="flex flex-col md:flex-row items-center gap-5 w-full">
                    <div className="w-full md:w-64 aspect-video rounded-xl overflow-hidden bg-zinc-950 border border-zinc-200 flex items-center justify-center shrink-0">
                      {probed.kind === 'video' ? (
                        <video
                          key={localPreviewUrl || probed.previewUrl}
                          src={localPreviewUrl || probed.previewUrl}
                          controls
                          playsInline
                          preload="metadata"
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <img
                          key={localPreviewUrl || probed.previewUrl}
                          src={localPreviewUrl || probed.previewUrl}
                          alt={probed.originalName}
                          className="w-full h-full object-contain bg-zinc-100"
                        />
                      )}
                    </div>

                    <div className="flex-1 min-w-0 text-center md:text-left">
                      <p className="text-xs font-semibold text-blue-600 mb-1">
                        Uploaded {probed.kind === 'video' ? 'Video' : 'Image'} Preview
                      </p>
                      <p className="font-display text-sm sm:text-base font-bold text-zinc-950 truncate">
                        {probed.originalName}
                      </p>
                      <p className="text-xs sm:text-sm text-zinc-500 mt-1 font-mono tabular-nums">
                        {probed.width}×{probed.height} ({probed.aspectRatioLabel}) · {probed.sizeLabel}
                      </p>
                    </div>

                    <button
                      type="button"
                      disabled={resizing}
                      onClick={triggerFilePicker}
                      className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                    >
                      <Upload className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>Change File</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4 w-full max-w-xl">
                    <div className="text-center sm:text-left min-w-0">
                      <p className="font-display text-sm sm:text-base font-bold text-zinc-950 truncate">
                        Drop a video or image here
                      </p>
                      <p className="text-xs sm:text-sm text-zinc-500 mt-0.5">
                        Supports MP4, MOV, WebM videos and PNG, JPG, WebP images
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={resizing}
                      onClick={triggerFilePicker}
                      className="inline-flex items-center justify-center gap-2 px-5 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                    >
                      <Upload className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>Upload Video or Image</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Error Alert */}
            {error && (
              <div
                role="alert"
                className="mt-4 p-4 bg-red-50/80 border border-red-200 rounded-xl flex items-start gap-3 text-red-900"
              >
                <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
                <p className="text-sm leading-relaxed">{error}</p>
              </div>
            )}

            {/* Resize Controls: Aspect Ratio & Scale + Target MB + Quality */}
            {probed && !uploading && (
              <form onSubmit={handleResizeSubmit} className="mt-6 pt-6 border-t border-zinc-200 space-y-6">
                {/* 1. Aspect Ratio & Scale Size */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <label className="text-sm font-semibold text-zinc-950">Aspect Ratio</label>
                      {previewDims && (
                        <span className="font-mono tabular-nums text-xs text-zinc-500">
                          Output: {previewDims.w}×{previewDims.h}
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 p-1 bg-zinc-100 rounded-xl">
                      {ASPECT_OPTIONS.map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setAspectRatio(opt.id)}
                          className={`py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                            aspectRatio === opt.id
                              ? 'bg-white text-zinc-950 shadow-xs'
                              : 'text-zinc-600 hover:text-zinc-950'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div
                    className={
                      probed.kind === 'image' || probed.hasAudio === false
                        ? 'opacity-60 pointer-events-none'
                        : ''
                    }
                  >
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <label
                        htmlFor="audio-clarity-input"
                        className="text-sm font-semibold text-zinc-950"
                      >
                        Voice & Audio Clarity
                      </label>
                      <span className="text-xs font-medium text-blue-600">
                        {probed.kind === 'image'
                          ? 'Videos with audio only'
                          : probed.hasAudio === false
                            ? 'No audio track detected'
                            : audioClarity === 0
                              ? 'Original audio (0%)'
                              : audioClarity <= 45
                                ? `Clean Voice (${audioClarity}%)`
                                : audioClarity <= 80
                                  ? `Studio Pro (${audioClarity}%)`
                                  : `Max Noise & Voice Repair (${audioClarity}%)`}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 bg-zinc-100 rounded-xl mb-2.5">
                      {AUDIO_CLARITY_PRESETS.map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => setAudioClarity(preset.value)}
                          className={`py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                            audioClarity === preset.value
                              ? 'bg-white text-zinc-950 shadow-xs'
                              : 'text-zinc-600 hover:text-zinc-950'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="flex-1">
                        <input
                          type="range"
                          min="0"
                          max="100"
                          step="1"
                          value={audioClarity}
                          onChange={(e) => setAudioClarity(Number(e.target.value))}
                          aria-label="Voice clarity and noise reduction adjustment percentage"
                          className="w-full h-2 bg-zinc-200 rounded-lg accent-blue-600 cursor-pointer block"
                        />
                        <div className="flex items-center justify-between text-[11px] font-mono tabular-nums text-zinc-400 mt-1">
                          <span>0% Original</span>
                          <span>100% Studio Repair</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <input
                          id="audio-clarity-input"
                          type="number"
                          min="0"
                          max="100"
                          step="1"
                          value={audioClarity}
                          onChange={(e) => {
                            const n = Number(e.target.value);
                            if (Number.isFinite(n)) {
                              setAudioClarity(Math.max(0, Math.min(100, Math.round(n))));
                            } else {
                              setAudioClarity(0);
                            }
                          }}
                          className="w-14 sm:w-16 min-h-[38px] px-2 sm:px-2.5 py-1.5 text-sm font-mono tabular-nums font-semibold text-zinc-950 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:bg-white focus:border-blue-600"
                        />
                        <span className="text-xs font-mono font-semibold text-zinc-500">%</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. Target File Size (KB / MB) — Lower or Higher + 3. Quality */}
                <div className="grid grid-cols-1 md:grid-cols-[1fr_280px] gap-5 md:gap-6 items-end">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <label
                        htmlFor="target-size-input"
                        className="text-sm font-semibold text-zinc-950"
                      >
                        Target File Size ({sizeUnit})
                      </label>
                      <span className="text-xs font-medium text-blue-600">
                        {sizeDirectionText}
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="flex-1">
                        <input
                          type="range"
                          min="0"
                          max="1000"
                          step="1"
                          value={sliderPos}
                          onChange={(e) => handleSliderChange(e.target.value)}
                          aria-label="Target file size slider from 2 KB to 50 MB"
                          className="w-full h-2 bg-zinc-200 rounded-lg accent-blue-600 cursor-pointer block"
                        />
                        <div className="flex items-center justify-between text-[11px] font-mono tabular-nums text-zinc-400 mt-1.5">
                          <span>2 KB</span>
                          <span>{formatTargetSize(sliderMaxKb)}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <input
                          id="target-size-input"
                          type="number"
                          min={sizeUnit === 'KB' ? '2' : '0.002'}
                          max={sizeUnit === 'KB' ? '204800' : '200'}
                          step="any"
                          value={targetSizeInput}
                          onChange={(e) => setTargetSizeInput(e.target.value)}
                          className="w-20 sm:w-24 min-h-[42px] px-2 sm:px-3 py-2 text-sm font-mono tabular-nums font-semibold text-zinc-950 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:bg-white focus:border-blue-600"
                        />
                        <div className="grid grid-cols-2 p-1 bg-zinc-100 rounded-xl">
                          {(['KB', 'MB'] as const).map((unit) => (
                            <button
                              key={unit}
                              type="button"
                              onClick={() => handleUnitSwitch(unit)}
                              className={`px-2.5 py-2 min-h-[34px] text-xs font-mono font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                                sizeUnit === unit
                                  ? 'bg-white text-zinc-950 shadow-xs'
                                  : 'text-zinc-600 hover:text-zinc-950'
                              }`}
                            >
                              {unit}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-semibold text-zinc-950 block mb-2">
                      Quality
                    </label>
                    <div className="grid grid-cols-3 gap-1.5 p-1 bg-zinc-100 rounded-xl">
                      {QUALITY_OPTIONS.map((opt) => (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => setQuality(opt.id)}
                          className={`py-2 min-h-[38px] text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                            quality === opt.id
                              ? 'bg-white text-zinc-950 shadow-xs'
                              : 'text-zinc-600 hover:text-zinc-950'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Submit Resize Action */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                  <p className="text-xs text-zinc-500">
                    Original: <span className="font-mono tabular-nums">{probed.sizeLabel}</span> ·{' '}
                    <span className="font-mono tabular-nums">
                      {probed.width}×{probed.height}
                    </span>
                  </p>
                  <button
                    type="submit"
                    disabled={resizing}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[48px] text-sm sm:text-base font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 rounded-xl transition-colors whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                  >
                    {resizing ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                        <span>Resizing {probed.kind === 'video' ? 'Video' : 'Image'}...</span>
                      </>
                    ) : (
                      <>
                        <SlidersHorizontal className="w-4 h-4 shrink-0" aria-hidden="true" />
                        <span>Resize {probed.kind === 'video' ? 'Video' : 'Image'}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* Output Preview & First-Click Download */}
            {result && !resizing && (
              <div className="mt-6 pt-6 border-t border-zinc-200">
                <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-6 items-center">
                  <div className="rounded-xl overflow-hidden bg-zinc-950 border border-zinc-200 aspect-video flex items-center justify-center">
                    {result.kind === 'video' ? (
                      <video
                        src={result.previewUrl}
                        controls
                        playsInline
                        preload="metadata"
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <img
                        src={result.previewUrl}
                        alt={result.outputFilename}
                        className="w-full h-full object-contain bg-zinc-100"
                      />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-zinc-500 mb-1.5">
                      <span className="text-emerald-700 font-semibold">Resize Complete</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {result.width}×{result.height}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums font-semibold text-zinc-800">
                        {probed ? `${probed.sizeLabel} → ${result.sizeLabel}` : result.sizeLabel}
                      </span>
                    </div>

                    <h2 className="font-display text-lg sm:text-xl font-bold text-zinc-950 truncate mb-4">
                      {result.outputFilename}
                    </h2>

                    <button
                      type="button"
                      disabled={downloading}
                      onClick={() => void handleDownloadResized()}
                      className={`inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[48px] w-full sm:w-auto text-sm sm:text-base font-semibold rounded-xl transition-colors whitespace-nowrap cursor-pointer disabled:cursor-wait focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 ${
                        downloaded
                          ? 'bg-emerald-600 text-white'
                          : downloading
                            ? 'bg-blue-600 text-white'
                            : 'bg-zinc-950 hover:bg-blue-600 text-white'
                      }`}
                    >
                      {downloading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                          <span>
                            {downloadProgress !== null && downloadProgress > 0
                              ? `Downloading (${downloadProgress}%)`
                              : 'Preparing download...'}
                          </span>
                        </>
                      ) : downloaded ? (
                        <>
                          <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                          <span>Downloaded</span>
                        </>
                      ) : (
                        <>
                          <ArrowDownToLine className="w-4 h-4 shrink-0" aria-hidden="true" />
                          <span>
                            {result.kind === 'video'
                              ? 'Download Resized Video'
                              : 'Download Resized Image'}
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Capabilities Section */}
      <section id="platforms" className="py-14 sm:py-20 border-t border-zinc-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-10 sm:mb-12">
            <h2
              className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-3"
              style={{ textWrap: 'balance' }}
            >
              Built for precise KB & MB control and aspect ratio resizing
            </h2>
            <p className="text-base text-zinc-600 leading-relaxed">
              Adjust both file size from 2 KB up to 50 MB and visual proportions for videos and
              images from one clean workspace.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12 sm:mb-16">
            {FEATURE_CARDS.map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.title}
                  className="p-5 bg-[#FAFAFB] border border-zinc-200 rounded-xl flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2.5 mb-2">
                      <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
                        <Icon className="w-4 h-4" aria-hidden="true" />
                      </div>
                      <h3 className="font-display text-base font-bold text-zinc-950">
                        {card.title}
                      </h3>
                    </div>
                    <p className="text-sm text-zinc-600 leading-relaxed">{card.note}</p>
                  </div>
                  <p className="font-mono text-xs text-zinc-500 pt-2 border-t border-zinc-200/80">
                    {card.formats}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {CAPABILITIES.map((cap) => (
              <div
                key={cap.num}
                className={`p-6 bg-white border border-zinc-200 rounded-2xl flex flex-col justify-between gap-4 ${cap.span}`}
              >
                <div>
                  <span className="font-mono tabular-nums text-xs font-semibold text-blue-600 block mb-2">
                    {cap.num}.
                  </span>
                  <h3 className="font-display text-lg font-bold text-zinc-950 mb-2">{cap.title}</h3>
                  <p className="text-sm sm:text-base text-zinc-600 leading-relaxed max-w-prose">
                    {cap.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-14 sm:py-20 border-t border-zinc-200 bg-[#FAFAFB]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div className="max-w-xl">
              <h2
                className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-2"
                style={{ textWrap: 'balance' }}
              >
                Three steps to resize any video or image
              </h2>
              <p className="text-base text-zinc-600">
                Fast resizing across mobile and desktop browsers with exact KB & MB targeting.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                window.setTimeout(() => triggerFilePicker(), 250);
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto cursor-pointer"
            >
              <ArrowUp className="w-4 h-4" aria-hidden="true" />
              <span>Upload Media Now</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {STEPS.map((step) => (
              <div key={step.number} className="p-6 bg-white border border-zinc-200 rounded-2xl">
                <span className="font-mono tabular-nums text-sm font-semibold text-blue-600 block mb-3">
                  {step.number}.
                </span>
                <h3 className="font-display text-lg font-bold text-zinc-950 mb-2">{step.title}</h3>
                <p className="text-sm sm:text-base text-zinc-600 leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section id="faq" className="py-14 sm:py-20 border-t border-zinc-200 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2
            className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-8"
            style={{ textWrap: 'balance' }}
          >
            Frequently asked questions
          </h2>

          <div className="divide-y divide-zinc-200 border border-zinc-200 rounded-2xl overflow-hidden bg-white">
            {FAQS.map((item, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div key={item.q}>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full px-5 py-4 min-h-[56px] text-left flex items-center justify-between gap-4 hover:bg-zinc-50 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-blue-600"
                  >
                    <span className="font-display text-sm sm:text-base font-semibold text-zinc-950">
                      {item.q}
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-zinc-500 shrink-0 transition-transform duration-150 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 text-sm sm:text-base text-zinc-600 leading-relaxed">
                      {item.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-zinc-200 bg-[#FAFAFB] py-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2">
              <BrandLogo className="w-6 h-6" />
              <p className="font-display text-base font-bold text-zinc-950">Audit Video</p>
            </div>
            <p className="text-xs text-zinc-500 mt-1.5 max-w-md leading-relaxed">
              Universal video downloader, Gemini watermark remover, and video & image size resizer.
              Uploaded files are processed temporarily and cleared automatically.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-zinc-600">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onNavigateDownloader();
              }}
              className="hover:text-zinc-950 transition-colors whitespace-nowrap"
            >
              Video Downloader
            </a>
            <a
              href="/watermark-remover"
              onClick={(e) => {
                e.preventDefault();
                onNavigateWatermark();
              }}
              className="hover:text-zinc-950 transition-colors whitespace-nowrap"
            >
              Gemini Remover
            </a>
            <a
              href="#how-it-works"
              className="hover:text-zinc-950 transition-colors whitespace-nowrap"
            >
              How It Works
            </a>
            <a href="#faq" className="hover:text-zinc-950 transition-colors whitespace-nowrap">
              FAQ
            </a>
          </div>
        </div>
      </footer>
    </>
  );
}
