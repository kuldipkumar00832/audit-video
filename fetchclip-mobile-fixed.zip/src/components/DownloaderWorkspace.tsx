import { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowDownToLine,
  Check,
  ClipboardPaste,
  Film,
  History,
  Link2,
  Loader2,
  Music,
  RotateCcw,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import type { ExtractedMedia, HistoryItem, MediaFormat } from '../types/media';

interface DownloaderWorkspaceProps {
  inputRef: React.RefObject<HTMLInputElement | null>;
  clipboardTrigger: number;
}

type FormatFilter = 'video' | 'audio';

const HISTORY_STORAGE_KEY = 'fetchclip_history_v1';
const SAMPLE_PUBLIC_VIDEO =
  'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4';

function detectPlatformLabel(urlStr: string): string | null {
  const trimmed = urlStr.trim().toLowerCase();
  if (!trimmed) return null;
  if (trimmed.includes('youtube.com') || trimmed.includes('youtu.be')) return 'YouTube';
  if (trimmed.includes('pinterest.') || trimmed.includes('pin.it')) return 'Pinterest';
  if (trimmed.includes('instagram.com') || trimmed.includes('instagr.am')) return 'Instagram';
  if (trimmed.includes('facebook.com') || trimmed.includes('fb.watch') || trimmed.includes('fb.com'))
    return 'Facebook';
  if (trimmed.includes('tiktok.com')) return 'TikTok';
  if (trimmed.includes('twitter.com') || trimmed.includes('x.com') || trimmed.includes('t.co'))
    return 'X (Twitter)';
  if (trimmed.includes('reddit.com') || trimmed.includes('redd.it')) return 'Reddit';
  if (trimmed.includes('vimeo.com')) return 'Vimeo';
  if (/\.(mp4|webm|mov|m4v|mp3|m4a)(\?|$)/i.test(trimmed)) return 'Direct Media';
  if (trimmed.includes('.')) return 'Web Video';
  return null;
}

function loadHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.slice(0, 8) : [];
  } catch {
    return [];
  }
}

export function DownloaderWorkspace({ inputRef, clipboardTrigger }: DownloaderWorkspaceProps) {
  const [urlInput, setUrlInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [clipboardNotice, setClipboardNotice] = useState<string | null>(null);
  const [media, setMedia] = useState<ExtractedMedia | null>(null);
  const [thumbFailed, setThumbFailed] = useState(false);
  const [formatFilter, setFormatFilter] = useState<FormatFilter>('video');
  const [downloadedToken, setDownloadedToken] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>(() => loadHistory());

  const abortRef = useRef<AbortController | null>(null);

  const detectedPlatform = useMemo(() => detectPlatformLabel(urlInput), [urlInput]);

  const hasVideoFormats = useMemo(
    () => Boolean(media?.formats.some((f) => f.hasVideo)),
    [media]
  );

  const hasAudioFormats = useMemo(
    () => Boolean(media?.formats.some((f) => !f.hasVideo && f.hasAudio)),
    [media]
  );

  const filteredFormats = useMemo(() => {
    if (!media) return [];
    if (formatFilter === 'audio') return media.formats.filter((f) => !f.hasVideo && f.hasAudio);
    return media.formats.filter((f) => f.hasVideo);
  }, [media, formatFilter]);

  useEffect(() => {
    if (clipboardTrigger > 0) {
      void handlePasteFromClipboard();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clipboardTrigger]);

  function saveHistoryItem(item: HistoryItem) {
    setHistory((prev) => {
      const filtered = prev.filter((h) => h.sourceUrl !== item.sourceUrl);
      const next = [item, ...filtered].slice(0, 8);
      try {
        localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage quota errors
      }
      return next;
    });
  }

  function clearHistory() {
    setHistory([]);
    try {
      localStorage.removeItem(HISTORY_STORAGE_KEY);
    } catch {
      // Ignore storage errors
    }
  }

  async function fetchVideoInfo(targetUrl: string) {
    const clean = targetUrl.trim();
    if (!clean) {
      setError('Please paste a video link before clicking Get Video.');
      inputRef.current?.focus();
      return;
    }

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    setError(null);
    setClipboardNotice(null);
    setMedia(null);
    setThumbFailed(false);
    setFormatFilter('video');
    setDownloadedToken(null);

    try {
      const response = await fetch('/api/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: clean }),
        signal: controller.signal,
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data?.error || 'Could not extract a downloadable video from this link.');
      }

      const extracted = data as ExtractedMedia;
      const hasVideo = extracted.formats.some((f) => f.hasVideo);
      setFormatFilter(hasVideo ? 'video' : 'audio');
      setMedia(extracted);
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        return;
      }
      setError(
        err instanceof Error
          ? err.message
          : 'Something went wrong while analyzing the link. Please try again.'
      );
    } finally {
      if (abortRef.current === controller) {
        setLoading(false);
      }
    }
  }

  async function handlePasteFromClipboard() {
    setClipboardNotice(null);
    try {
      if (navigator.clipboard?.readText) {
        const text = (await navigator.clipboard.readText()).trim();
        if (text) {
          setUrlInput(text);
          setError(null);
          if (/^https?:\/\//i.test(text) || text.includes('.')) {
            void fetchVideoInfo(text);
          }
          return;
        }
        setClipboardNotice('Your clipboard is empty. Copy a video link first, then tap Paste.');
      }
    } catch {
      setClipboardNotice('Clipboard access was blocked by your browser. Tap the box and paste manually.');
    }
    inputRef.current?.focus();
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    void fetchVideoInfo(urlInput);
  }

  function handleDownloadFormat(fmt: MediaFormat) {
    if (!media) return;
    setDownloadedToken(fmt.downloadToken);

    const anchor = document.createElement('a');
    anchor.href = `/api/download?token=${encodeURIComponent(fmt.downloadToken)}`;
    anchor.download = '';
    anchor.rel = 'noopener';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);

    saveHistoryItem({
      id: `${media.id}-${fmt.id}`,
      title: media.title,
      platformName: media.platformName,
      sourceUrl: media.sourceUrl,
      quality: fmt.quality,
      ext: fmt.ext.toUpperCase(),
      savedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    });

    window.setTimeout(() => {
      setDownloadedToken((current) => (current === fmt.downloadToken ? null : current));
    }, 2600);
  }

  function handleTrySample() {
    setUrlInput(SAMPLE_PUBLIC_VIDEO);
    void fetchVideoInfo(SAMPLE_PUBLIC_VIDEO);
  }

  return (
    <section id="downloader" className="pt-10 pb-14 sm:pt-14 sm:pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Proposition */}
        <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-10">
          <p className="text-xs sm:text-sm font-medium text-blue-600 mb-3 tracking-wide">
            Universal Video & Audio Saver
          </p>
          <h1
            className="font-display font-bold tracking-tight text-zinc-950 leading-[1.1] mb-4"
            style={{ fontSize: 'clamp(2.1rem, 4.4vw, 3.35rem)', textWrap: 'balance' }}
          >
            Paste any video link. Download it in seconds.
          </h1>
          <p className="text-base sm:text-lg text-zinc-600 leading-relaxed max-w-xl mx-auto">
            Save public videos from YouTube, Pinterest, Instagram, Facebook, TikTok, Reddit, Vimeo,
            and direct web links in MP4 or MP3.
          </p>
        </div>

        {/* Primary URL Input Workspace */}
        <div className="bg-white border border-zinc-200 rounded-2xl p-3 sm:p-4 shadow-sm">
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1 flex items-center">
              <Link2
                className="w-4 h-4 text-zinc-400 absolute left-3.5 pointer-events-none shrink-0"
                aria-hidden="true"
              />
              <input
                ref={inputRef}
                type="url"
                inputMode="url"
                autoComplete="off"
                autoCorrect="off"
                spellCheck={false}
                value={urlInput}
                onChange={(e) => {
                  setUrlInput(e.target.value);
                  if (error) setError(null);
                  if (clipboardNotice) setClipboardNotice(null);
                }}
                placeholder="Paste video URL (YouTube, Pinterest, Instagram, Facebook...)"
                aria-label="Video URL"
                className="w-full min-h-[48px] pl-10 pr-24 py-3 text-sm sm:text-base text-zinc-950 placeholder:text-zinc-400 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:bg-white focus:border-blue-600 focus:ring-2 focus:ring-blue-600/15 transition-all"
              />

              <div className="absolute right-2 flex items-center gap-1">
                {urlInput ? (
                  <button
                    type="button"
                    onClick={() => {
                      setUrlInput('');
                      setError(null);
                      setMedia(null);
                      inputRef.current?.focus();
                    }}
                    aria-label="Clear URL"
                    className="inline-flex items-center justify-center w-9 h-9 text-zinc-500 hover:text-zinc-900 hover:bg-zinc-200/70 rounded-lg transition-colors cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => void handlePasteFromClipboard()}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 min-h-[34px] text-xs font-semibold text-zinc-700 bg-white border border-zinc-200 hover:border-zinc-300 hover:bg-zinc-50 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <ClipboardPaste className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Paste</span>
                  </button>
                )}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[48px] text-sm sm:text-base font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 rounded-xl transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                  <span>Analyzing...</span>
                </>
              ) : (
                <>
                  <ArrowDownToLine className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>Get Video</span>
                </>
              )}
            </button>
          </form>

          {/* Subtle status & helper row (zero pills) */}
          <div className="mt-2.5 px-1 flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-500">
            <div className="flex items-center gap-2 min-w-0">
              {detectedPlatform ? (
                <span className="text-zinc-700 font-medium truncate">
                  Detected source: {detectedPlatform}
                </span>
              ) : (
                <span>Supports MP4, WebM, HLS streams, and MP3 audio extraction</span>
              )}
            </div>
            <button
              type="button"
              onClick={handleTrySample}
              disabled={loading}
              className="text-zinc-600 hover:text-blue-600 underline underline-offset-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Test with sample video
            </button>
          </div>
        </div>

        {/* Clipboard Permission Notice */}
        {clipboardNotice && (
          <div
            role="status"
            className="mt-4 px-4 py-3 bg-white border border-zinc-200 rounded-xl text-sm text-zinc-700 flex items-center justify-between gap-3"
          >
            <span>{clipboardNotice}</span>
            <button
              type="button"
              onClick={() => setClipboardNotice(null)}
              aria-label="Dismiss notice"
              className="text-zinc-400 hover:text-zinc-700 p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Error Alert */}
        {error && (
          <div
            role="alert"
            className="mt-5 p-4 bg-red-50/80 border border-red-200 rounded-xl flex items-start gap-3 text-red-900"
          >
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold">Unable to process this link</p>
              <p className="text-sm text-red-800 mt-0.5 leading-relaxed">{error}</p>
            </div>
            <button
              type="button"
              onClick={() => {
                setError(null);
                inputRef.current?.focus();
              }}
              className="inline-flex items-center gap-1 px-3 py-1.5 min-h-[36px] text-xs font-semibold text-red-800 bg-white border border-red-200 hover:bg-red-50 rounded-lg shrink-0 cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Loading Skeleton */}
        {loading && (
          <div
            aria-busy="true"
            aria-label="Fetching video formats"
            className="mt-6 bg-white border border-zinc-200 rounded-2xl p-4 sm:p-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-6">
              <div className="aspect-video w-full rounded-xl bg-zinc-100 animate-pulse" />
              <div className="space-y-4">
                <div className="h-3.5 w-40 bg-zinc-100 rounded animate-pulse" />
                <div className="h-6 w-3/4 bg-zinc-100 rounded animate-pulse" />
                <div className="space-y-2.5 pt-2">
                  <div className="h-12 w-full bg-zinc-100 rounded-xl animate-pulse" />
                  <div className="h-12 w-full bg-zinc-100 rounded-xl animate-pulse" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Extracted Media Result Card */}
        {media && !loading && (
          <div className="mt-6 bg-white border border-zinc-200 rounded-2xl p-4 sm:p-6">
            <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-6 items-start">
              {/* Preview Thumbnail */}
              <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-zinc-100 border border-zinc-200/80">
                {media.thumbnailProxyUrl && !thumbFailed ? (
                  <img
                    src={media.thumbnailProxyUrl}
                    alt={media.title}
                    referrerPolicy="no-referrer"
                    onError={() => setThumbFailed(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-zinc-100 to-zinc-200/70 text-zinc-500 p-4 text-center">
                    <Film className="w-8 h-8 text-zinc-400" aria-hidden="true" />
                    <span className="text-xs font-medium text-zinc-600">
                      {media.platformName} Media Preview
                    </span>
                  </div>
                )}

                {media.durationLabel && (
                  <span className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-zinc-950/85 text-white font-mono tabular-nums text-xs font-medium">
                    {media.durationLabel}
                  </span>
                )}
              </div>

              {/* Metadata & Format Selector */}
              <div className="min-w-0">
                {/* Unboxed metadata row */}
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-zinc-500 mb-1.5">
                  <span className="text-blue-600 font-semibold">{media.platformName}</span>
                  {media.author && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="truncate max-w-[200px]">{media.author}</span>
                    </>
                  )}
                  {media.durationLabel && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{media.durationLabel}</span>
                    </>
                  )}
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {media.formats.length} {media.formats.length === 1 ? 'option' : 'options'}
                  </span>
                </div>

                <h2
                  className="font-display text-lg sm:text-xl font-bold text-zinc-950 leading-snug mb-4 break-words"
                  style={{ textWrap: 'balance' }}
                >
                  {media.title}
                </h2>

                {/* Interactive Filter Tabs */}
                {hasVideoFormats && hasAudioFormats && (
                  <div
                    role="tablist"
                    aria-label="Format category filter"
                    className="inline-flex items-center gap-1 p-1 bg-zinc-100 rounded-lg mb-3"
                  >
                    {(
                      [
                        { id: 'video', label: 'Video' },
                        { id: 'audio', label: 'Audio Only' },
                      ] as const
                    ).map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        role="tab"
                        aria-selected={formatFilter === tab.id}
                        onClick={() => setFormatFilter(tab.id)}
                        className={`px-3 py-1.5 min-h-[34px] text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          formatFilter === tab.id
                            ? 'bg-white text-zinc-950 shadow-xs'
                            : 'text-zinc-600 hover:text-zinc-950'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                )}

                {/* Download Format Rows */}
                <div className="divide-y divide-zinc-200 border border-zinc-200 rounded-xl overflow-hidden">
                  {filteredFormats.map((fmt) => {
                    const isJustTriggered = downloadedToken === fmt.downloadToken;
                    return (
                      <div
                        key={fmt.id}
                        className="flex items-center justify-between gap-3 px-3.5 py-3 bg-white hover:bg-zinc-50/80 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-9 h-9 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-700 shrink-0">
                            {fmt.hasVideo ? (
                              <Film className="w-4 h-4" aria-hidden="true" />
                            ) : (
                              <Music className="w-4 h-4" aria-hidden="true" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-zinc-950 truncate">
                              {fmt.label}
                            </p>
                            <div className="flex flex-wrap items-center gap-x-2 text-xs text-zinc-500 mt-0.5">
                              <span className="font-mono uppercase">{fmt.ext}</span>
                              <span aria-hidden="true">·</span>
                              <span className="inline-flex items-center gap-1">
                                {fmt.hasAudio ? (
                                  <>
                                    <Volume2 className="w-3 h-3" aria-hidden="true" />
                                    <span>With Audio</span>
                                  </>
                                ) : (
                                  <>
                                    <VolumeX className="w-3 h-3" aria-hidden="true" />
                                    <span>Video Only</span>
                                  </>
                                )}
                              </span>
                              {fmt.sizeLabel && (
                                <>
                                  <span aria-hidden="true">·</span>
                                  <span className="font-mono tabular-nums">{fmt.sizeLabel}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDownloadFormat(fmt)}
                          className={`inline-flex items-center justify-center gap-1.5 px-4 py-2 min-h-[40px] text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 ${
                            isJustTriggered
                              ? 'bg-emerald-600 text-white'
                              : 'bg-zinc-950 hover:bg-blue-600 text-white'
                          }`}
                        >
                          {isJustTriggered ? (
                            <>
                              <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                              <span>Started</span>
                            </>
                          ) : (
                            <>
                              <ArrowDownToLine className="w-4 h-4 shrink-0" aria-hidden="true" />
                              <span>Download</span>
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Recent Downloads (Local Browser History) */}
        {history.length > 0 && (
          <div className="mt-8 bg-white border border-zinc-200 rounded-2xl p-4 sm:p-5">
            <div className="flex items-center justify-between gap-4 pb-3 border-b border-zinc-200">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-zinc-500" aria-hidden="true" />
                <h3 className="font-display text-sm font-semibold text-zinc-950">
                  Recent Downloads
                </h3>
              </div>
              <button
                type="button"
                onClick={clearHistory}
                className="inline-flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-zinc-900 transition-colors cursor-pointer whitespace-nowrap"
              >
                <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Clear</span>
              </button>
            </div>

            <div className="divide-y divide-zinc-100">
              {history.map((item) => (
                <div
                  key={item.id}
                  className="py-3 flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-zinc-900 truncate">{item.title}</p>
                    <div className="flex items-center gap-2 text-xs text-zinc-500 mt-0.5">
                      <span>{item.platformName}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{item.quality}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{item.ext}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{item.savedAt}</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setUrlInput(item.sourceUrl);
                      void fetchVideoInfo(item.sourceUrl);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="px-3 py-1.5 min-h-[36px] text-xs font-semibold text-zinc-700 bg-zinc-100 hover:bg-zinc-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Load Again
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
