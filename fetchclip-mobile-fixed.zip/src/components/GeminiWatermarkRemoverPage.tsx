import { useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowDownToLine,
  ArrowUp,
  Check,
  ChevronDown,
  Film,
  Image as ImageIcon,
  Loader2,
  ShieldCheck,
  Sparkles,
  Upload,
} from 'lucide-react';
import type { ProcessedWatermarkResult } from '../types/media';
import { BrandLogo } from './BrandLogo';

interface GeminiWatermarkRemoverPageProps {
  fileInputRef: React.RefObject<HTMLInputElement | null>;
  onNavigateDownloader: () => void;
}

const SUPPORTED_MEDIA_CARDS = [
  {
    title: 'Gemini AI Videos',
    formats: 'MP4 · MOV · WebM · M4V',
    note: 'Automatically detects and removes Gemini and Veo corner watermarks from AI videos.',
    icon: Film,
  },
  {
    title: 'Gemini AI Images',
    formats: 'PNG · JPG · JPEG · WebP',
    note: 'Removes the bottom-right Gemini sparkle watermark instantly upon upload.',
    icon: ImageIcon,
  },
  {
    title: 'Direct File Upload',
    formats: 'Up to 150 MB per file',
    note: 'Select videos or images straight from your phone gallery or desktop folders.',
    icon: Upload,
  },
  {
    title: 'Gemini-Only Target',
    formats: 'Zero manual selection needed',
    note: 'Targets only the Gemini corner watermark while keeping the rest of your frame untouched.',
    icon: Sparkles,
  },
];

const CAPABILITIES = [
  {
    num: '01',
    title: 'Targeted Gemini Corner Removal',
    description:
      'Designed specifically for Gemini AI videos and images. Only the Gemini watermark in the corner is removed using surrounding pixel interpolation, leaving subjects, text, and scenery intact.',
    span: 'md:col-span-2',
  },
  {
    num: '02',
    title: 'Original Resolution & Audio Kept',
    description:
      'Videos retain their original dimensions and audio track while exporting cleanly to universal MP4.',
    span: 'md:col-span-1',
  },
  {
    num: '03',
    title: 'Automatic Processing on Upload',
    description:
      'No settings, region boxes, or prompts to configure. Simply upload a file and your clean media is ready to download automatically.',
    span: 'md:col-span-1',
  },
  {
    num: '04',
    title: 'Fast Direct Streaming & Cleanup',
    description:
      'Files stream directly to the processor with live upload progress and are automatically cleared from temporary storage after processing.',
    span: 'md:col-span-2',
  },
];

const STEPS = [
  {
    number: '01',
    title: 'Upload your video or image',
    description:
      'Tap Upload Video or Image (or drag and drop a file) directly from your phone or computer.',
  },
  {
    number: '02',
    title: 'Automatic Gemini removal',
    description:
      'As soon as the upload finishes, the Gemini watermark is detected and removed automatically with zero extra prompts.',
  },
  {
    number: '03',
    title: 'Download the clean file',
    description:
      'Preview the cleaned video or image and tap Download to save it directly to your device.',
  },
];

const FAQS = [
  {
    q: 'Which watermarks does this tool remove?',
    a: 'It is built exclusively to remove the Gemini AI watermark on Gemini-generated videos and images while leaving every other part of your media unchanged.',
  },
  {
    q: 'Can I upload both videos and images?',
    a: 'Yes. You can upload both AI videos (MP4, MOV, WebM, M4V) and AI images (PNG, JPG, JPEG, WebP) directly from your device.',
  },
  {
    q: 'Do I need to mark or select the watermark manually?',
    a: 'No. Watermark removal starts automatically the moment your file finishes uploading, with no manual selection or extra steps.',
  },
  {
    q: 'Are original audio and resolution preserved?',
    a: 'Yes. Your video keeps its original resolution and audio track, and images export at full resolution.',
  },
];

export function GeminiWatermarkRemoverPage({
  fileInputRef,
  onNavigateDownloader,
}: GeminiWatermarkRemoverPageProps) {
  const [dragActive, setDragActive] = useState(false);
  const [phase, setPhase] = useState<'idle' | 'uploading' | 'processing' | 'done'>('idle');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedName, setSelectedName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ProcessedWatermarkResult | null>(null);
  const [downloading, setDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [downloaded, setDownloaded] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const activeXhrRef = useRef<XMLHttpRequest | null>(null);

  function triggerFilePicker() {
    fileInputRef.current?.click();
  }

  function handleFileUpload(file: File) {
    const isMedia =
      file.type.startsWith('video/') ||
      file.type.startsWith('image/') ||
      /\.(mp4|webm|mov|m4v|mkv|avi|png|jpe?g|webp|bmp)$/i.test(file.name);

    if (!isMedia) {
      setError('Please choose a valid video or image file.');
      return;
    }

    if (file.size > 150 * 1024 * 1024) {
      setError('File size must be 150 MB or smaller.');
      return;
    }

    activeXhrRef.current?.abort();

    setError(null);
    setResult(null);
    setDownloaded(false);
    setSelectedName(file.name);
    setPhase('uploading');
    setUploadProgress(0);

    const xhr = new XMLHttpRequest();
    activeXhrRef.current = xhr;

    xhr.open('POST', '/api/remove-watermark', true);
    xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
    xhr.setRequestHeader('X-File-Name', encodeURIComponent(file.name));

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && event.total > 0) {
        const pct = Math.min(100, Math.round((event.loaded / event.total) * 100));
        setUploadProgress(pct);
        if (pct >= 100) {
          setPhase('processing');
        }
      }
    };

    xhr.upload.onload = () => {
      setUploadProgress(100);
      setPhase('processing');
    };

    xhr.onload = () => {
      try {
        const data = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300) {
          setResult(data as ProcessedWatermarkResult);
          setPhase('done');
        } else {
          setError(data?.error || 'Could not remove watermark from this file.');
          setPhase('idle');
        }
      } catch {
        setError('Unexpected response while processing your file.');
        setPhase('idle');
      }
    };

    xhr.onerror = () => {
      setError('Upload connection failed. Please try again.');
      setPhase('idle');
    };

    xhr.onabort = () => {
      setPhase('idle');
    };

    xhr.send(file);
  }

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
    e.target.value = '';
  }

  function handleDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragActive(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  }

  async function handleDownloadClean() {
    if (!result || downloading) return;
    setError(null);
    setDownloading(true);
    setDownloadProgress(0);
    setDownloaded(false);

    try {
      const response = await fetch(result.downloadUrl, { cache: 'no-store' });
      if (!response.ok) {
        let message = 'Unable to download the processed file. Please upload it again.';
        try {
          const errJson = await response.json();
          if (errJson?.error) message = errJson.error;
        } catch {
          // Ignore non-JSON error body
        }
        throw new Error(message);
      }

      const contentLength = Number(response.headers.get('content-length') || result.sizeBytes || 0);
      let blob: Blob;

      if (response.body) {
        const reader = response.body.getReader();
        const chunks: Uint8Array<ArrayBuffer>[] = [];
        let received = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            const copy = new Uint8Array(value.byteLength);
            copy.set(value);
            chunks.push(copy);
            received += value.byteLength;
            if (contentLength > 0) {
              setDownloadProgress(Math.min(100, Math.round((received / contentLength) * 100)));
            }
          }
        }

        if (received === 0) {
          throw new Error('Downloaded file was empty. Please try again.');
        }

        blob = new Blob(chunks, { type: result.mimeType });
      } else {
        blob = await response.blob();
        if (blob.size === 0) {
          throw new Error('Downloaded file was empty. Please try again.');
        }
      }

      const blobUrl = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = blobUrl;
      anchor.download = result.cleanFilename;
      anchor.style.display = 'none';
      document.body.appendChild(anchor);
      anchor.click();

      window.setTimeout(() => {
        if (anchor.parentNode) {
          anchor.parentNode.removeChild(anchor);
        }
      }, 1000);

      window.setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
      }, 60000);

      setDownloaded(true);
      window.setTimeout(() => {
        setDownloaded(false);
      }, 2600);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Download failed. Please try again.'
      );
    } finally {
      setDownloading(false);
      setDownloadProgress(null);
    }
  }

  const isBusy = phase === 'uploading' || phase === 'processing';

  return (
    <>
      {/* Main Hero & Strictly Two-Option Workspace (Upload & Download) */}
      <section id="watermark-tool" className="pt-10 pb-14 sm:pt-14 sm:pb-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-10">
            <p className="text-xs sm:text-sm font-medium text-blue-600 mb-3 tracking-wide">
              Automatic Gemini Watermark Remover
            </p>
            <h1
              className="font-display font-bold tracking-tight text-zinc-950 leading-[1.1] mb-4"
              style={{ fontSize: 'clamp(2.1rem, 4.4vw, 3.35rem)', textWrap: 'balance' }}
            >
              Upload Gemini video or image. Download it clean.
            </h1>
            <p className="text-base sm:text-lg text-zinc-600 leading-relaxed max-w-xl mx-auto">
              Upload any Gemini AI video or image directly from your device. The Gemini watermark is
              removed automatically and ready to download in seconds.
            </p>
          </div>

          {/* Tool Card: Strictly Upload & Download */}
          <div className="bg-white border border-zinc-200 rounded-2xl p-4 sm:p-6 shadow-sm">
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*,image/*"
              onChange={handleInputChange}
              className="sr-only"
              aria-label="Upload video or image file"
            />

            {/* Option 1: Direct File Upload Dropzone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                if (!isBusy) setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={handleDrop}
              className={`rounded-xl border-2 border-dashed p-6 sm:p-8 text-center transition-colors ${
                dragActive
                  ? 'border-blue-600 bg-blue-50/60'
                  : 'border-zinc-200 bg-[#FAFAFB] hover:border-zinc-300'
              }`}
            >
              <div className="max-w-md mx-auto flex flex-col items-center">
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                  {isBusy ? (
                    <Loader2 className="w-6 h-6 animate-spin" aria-hidden="true" />
                  ) : (
                    <Upload className="w-6 h-6" aria-hidden="true" />
                  )}
                </div>

                {isBusy ? (
                  <div className="w-full space-y-2.5">
                    <p className="font-display text-base font-bold text-zinc-950">
                      {phase === 'uploading'
                        ? `Uploading file (${uploadProgress}%)`
                        : 'Removing Gemini watermark automatically...'}
                    </p>
                    {selectedName && (
                      <p className="text-xs text-zinc-500 truncate">{selectedName}</p>
                    )}
                    <div className="w-full h-2 bg-zinc-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600 transition-all duration-150"
                        style={{
                          width: `${phase === 'processing' ? 100 : Math.max(8, uploadProgress)}%`,
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="font-display text-base sm:text-lg font-bold text-zinc-950 mb-1">
                      Drop your Gemini video or image here
                    </p>
                    <p className="text-sm text-zinc-500 mb-5">
                      Supports MP4, MOV, WebM videos and PNG, JPG, WebP images
                    </p>
                    <button
                      type="button"
                      onClick={triggerFilePicker}
                      className="inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[48px] text-sm sm:text-base font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-[0.99] rounded-xl transition-all duration-150 whitespace-nowrap cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                    >
                      <Upload className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>Upload Video or Image</span>
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Error Notice */}
            {error && (
              <div
                role="alert"
                className="mt-4 p-4 bg-red-50/80 border border-red-200 rounded-xl flex items-start gap-3 text-red-900"
              >
                <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" aria-hidden="true" />
                <p className="text-sm leading-relaxed">{error}</p>
              </div>
            )}

            {/* Option 2: Clean Result Preview & Single Download Action */}
            {result && phase === 'done' && (
              <div className="mt-6 pt-6 border-t border-zinc-200">
                <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-5 md:gap-6 items-center">
                  <div className="rounded-xl overflow-hidden bg-zinc-950 border border-zinc-200 aspect-video flex items-center justify-center">
                    {result.kind === 'video' ? (
                      <video
                        src={result.previewUrl}
                        controls
                        playsInline
                        preload="metadata"
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <img
                        src={result.previewUrl}
                        alt={result.cleanFilename}
                        className="w-full h-full object-contain bg-zinc-100"
                      />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-zinc-500 mb-1.5">
                      <span className="text-emerald-700 font-semibold inline-flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Gemini Watermark Removed</span>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="uppercase font-mono">
                        {result.kind === 'video' ? 'MP4' : result.cleanFilename.split('.').pop()}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {result.width}×{result.height}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{result.sizeLabel}</span>
                    </div>

                    <h2 className="font-display text-lg sm:text-xl font-bold text-zinc-950 truncate mb-4">
                      {result.cleanFilename}
                    </h2>

                    <button
                      type="button"
                      disabled={downloading}
                      onClick={() => void handleDownloadClean()}
                      className={`inline-flex items-center justify-center gap-2 px-6 py-3 min-h-[48px] w-full sm:w-auto text-sm sm:text-base font-semibold rounded-xl transition-colors whitespace-nowrap cursor-pointer disabled:cursor-wait focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 ${
                        downloaded
                          ? 'bg-emerald-600 text-white'
                          : downloading
                            ? 'bg-blue-600 text-white'
                            : 'bg-zinc-950 hover:bg-blue-600 text-white'
                      }`}
                    >
                      {downloading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                          <span>
                            {downloadProgress !== null && downloadProgress > 0
                              ? `Downloading (${downloadProgress}%)`
                              : 'Preparing download...'}
                          </span>
                        </>
                      ) : downloaded ? (
                        <>
                          <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                          <span>Downloaded</span>
                        </>
                      ) : (
                        <>
                          <ArrowDownToLine className="w-4 h-4 shrink-0" aria-hidden="true" />
                          <span>
                            {result.kind === 'video'
                              ? 'Download Clean Video'
                              : 'Download Clean Image'}
                          </span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Supported Media & Capabilities Section (Same Visual Rhythm & Color System) */}
      <section id="platforms" className="py-14 sm:py-20 border-t border-zinc-200 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-10 sm:mb-12">
            <h2
              className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-3"
              style={{ textWrap: 'balance' }}
            >
              Built for Gemini AI videos and images
            </h2>
            <p className="text-base text-zinc-600 leading-relaxed">
              Upload any file straight from your device. Only the Gemini watermark is removed
              automatically while preserving your full video and image quality.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12 sm:mb-16">
            {SUPPORTED_MEDIA_CARDS.map((card) => {
              const Icon = card.icon;
              return (
                <div
                  key={card.title}
                  className="p-5 bg-[#FAFAFB] border border-zinc-200 rounded-xl flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2.5 mb-2">
                      <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
                        <Icon className="w-4 h-4" aria-hidden="true" />
                      </div>
                      <h3 className="font-display text-base font-bold text-zinc-950">
                        {card.title}
                      </h3>
                    </div>
                    <p className="text-sm text-zinc-600 leading-relaxed">{card.note}</p>
                  </div>
                  <p className="font-mono text-xs text-zinc-500 pt-2 border-t border-zinc-200/80">
                    {card.formats}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {CAPABILITIES.map((cap) => (
              <div
                key={cap.num}
                className={`p-6 bg-white border border-zinc-200 rounded-2xl flex flex-col justify-between gap-4 ${cap.span}`}
              >
                <div>
                  <span className="font-mono tabular-nums text-xs font-semibold text-blue-600 block mb-2">
                    {cap.num}.
                  </span>
                  <h3 className="font-display text-lg font-bold text-zinc-950 mb-2">{cap.title}</h3>
                  <p className="text-sm sm:text-base text-zinc-600 leading-relaxed max-w-prose">
                    {cap.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-14 sm:py-20 border-t border-zinc-200 bg-[#FAFAFB]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div className="max-w-xl">
              <h2
                className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-2"
                style={{ textWrap: 'balance' }}
              >
                Three steps from upload to clean media
              </h2>
              <p className="text-base text-zinc-600">
                Fast automatic Gemini watermark removal on both mobile and desktop browsers.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                window.setTimeout(() => triggerFilePicker(), 250);
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto cursor-pointer"
            >
              <ArrowUp className="w-4 h-4" aria-hidden="true" />
              <span>Upload Media Now</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {STEPS.map((step) => (
              <div key={step.number} className="p-6 bg-white border border-zinc-200 rounded-2xl">
                <span className="font-mono tabular-nums text-sm font-semibold text-blue-600 block mb-3">
                  {step.number}.
                </span>
                <h3 className="font-display text-lg font-bold text-zinc-950 mb-2">{step.title}</h3>
                <p className="text-sm sm:text-base text-zinc-600 leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section id="faq" className="py-14 sm:py-20 border-t border-zinc-200 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2
            className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-8"
            style={{ textWrap: 'balance' }}
          >
            Frequently asked questions
          </h2>

          <div className="divide-y divide-zinc-200 border border-zinc-200 rounded-2xl overflow-hidden bg-white">
            {FAQS.map((item, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div key={item.q}>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full px-5 py-4 min-h-[56px] text-left flex items-center justify-between gap-4 hover:bg-zinc-50 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-blue-600"
                  >
                    <span className="font-display text-sm sm:text-base font-semibold text-zinc-950">
                      {item.q}
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-zinc-500 shrink-0 transition-transform duration-150 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 text-sm sm:text-base text-zinc-600 leading-relaxed">
                      {item.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-zinc-200 bg-[#FAFAFB] py-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2">
              <BrandLogo className="w-6 h-6" />
              <p className="font-display text-base font-bold text-zinc-950">Audit Video</p>
            </div>
            <p className="text-xs text-zinc-500 mt-1.5 max-w-md leading-relaxed">
              Universal web video saver and automatic Gemini AI watermark remover. Uploaded media is
              processed temporarily and never stored permanently.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-zinc-600">
            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                onNavigateDownloader();
              }}
              className="hover:text-zinc-950 transition-colors whitespace-nowrap"
            >
              Video Downloader
            </a>
            <a href="#platforms" className="hover:text-zinc-950 transition-colors whitespace-nowrap">
              Supported Media
            </a>
            <a
              href="#how-it-works"
              className="hover:text-zinc-950 transition-colors whitespace-nowrap"
            >
              How It Works
            </a>
            <a href="#faq" className="hover:text-zinc-950 transition-colors whitespace-nowrap">
              FAQ
            </a>
          </div>
        </div>
      </footer>
    </>
  );
}
