import { useState } from 'react';
import { ClipboardPaste, Menu, Upload, X } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

export type ActivePage = 'downloader' | 'watermark-remover' | 'resizer';

interface HeaderProps {
  activePage: ActivePage;
  onNavigatePage: (page: ActivePage, sectionId?: string) => void;
  onPrimaryAction: () => void;
}

export function Header({ activePage, onNavigatePage, onPrimaryAction }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLinkClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    page: ActivePage,
    sectionId?: string
  ) => {
    e.preventDefault();
    setMobileOpen(false);
    onNavigatePage(page, sectionId);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#FAFAFB]/95 backdrop-blur-sm border-b border-zinc-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3 sm:gap-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <a
          href="/"
          onClick={(e) => handleLinkClick(e, 'downloader', 'downloader')}
          className="inline-flex items-center gap-2 sm:gap-2.5 font-display text-lg sm:text-xl font-bold tracking-tight text-zinc-950 whitespace-nowrap min-w-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
        >
          <BrandLogo className="w-7 h-7" />
          <span>Audit Video</span>
        </a>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-5 text-sm font-medium text-zinc-600"
        >
          <a
            href="/"
            onClick={(e) => handleLinkClick(e, 'downloader', 'downloader')}
            className={`transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded ${
              activePage === 'downloader'
                ? 'text-zinc-950 font-semibold underline underline-offset-4'
                : 'hover:text-zinc-950 hover:underline underline-offset-4'
            }`}
          >
            Downloader
          </a>
          <a
            href="/watermark-remover"
            onClick={(e) => handleLinkClick(e, 'watermark-remover', 'watermark-tool')}
            className={`transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded ${
              activePage === 'watermark-remover'
                ? 'text-zinc-950 font-semibold underline underline-offset-4'
                : 'hover:text-zinc-950 hover:underline underline-offset-4'
            }`}
          >
            Gemini Remover
          </a>
          <a
            href="/resizer"
            onClick={(e) => handleLinkClick(e, 'resizer', 'resizer-tool')}
            className={`transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded ${
              activePage === 'resizer'
                ? 'text-zinc-950 font-semibold underline underline-offset-4'
                : 'hover:text-zinc-950 hover:underline underline-offset-4'
            }`}
          >
            Media Resizer
          </a>
          <a
            href="#how-it-works"
            onClick={(e) => handleLinkClick(e, activePage, 'how-it-works')}
            className="hover:text-zinc-950 hover:underline underline-offset-4 transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
          >
            How It Works
          </a>
          <a
            href="#faq"
            onClick={(e) => handleLinkClick(e, activePage, 'faq')}
            className="hover:text-zinc-950 hover:underline underline-offset-4 transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
          >
            FAQ
          </a>
        </nav>

        {/* Zone 3: 1 primary action (+ mobile menu button on small screens) */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onPrimaryAction}
            aria-label={activePage === 'downloader' ? 'Paste Link' : 'Upload Media'}
            className="inline-flex items-center gap-2 px-3 sm:px-4 py-2 min-h-[40px] min-w-[40px] justify-center text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-[0.99] rounded-lg transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
          >
            {activePage === 'downloader' ? (
              <>
                <ClipboardPaste className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span className="hidden sm:inline">Paste Link</span>
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span className="hidden sm:inline">Upload Media</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden border-t border-zinc-200 bg-white px-4 py-3 flex flex-col gap-1"
        >
          <a
            href="/"
            onClick={(e) => handleLinkClick(e, 'downloader', 'downloader')}
            className={`px-3 py-2.5 min-h-[44px] flex items-center text-sm rounded-lg transition-colors ${
              activePage === 'downloader'
                ? 'font-semibold text-blue-600 bg-blue-50/70'
                : 'font-medium text-zinc-700 hover:text-zinc-950 hover:bg-zinc-50'
            }`}
          >
            Downloader
          </a>
          <a
            href="/watermark-remover"
            onClick={(e) => handleLinkClick(e, 'watermark-remover', 'watermark-tool')}
            className={`px-3 py-2.5 min-h-[44px] flex items-center text-sm rounded-lg transition-colors ${
              activePage === 'watermark-remover'
                ? 'font-semibold text-blue-600 bg-blue-50/70'
                : 'font-medium text-zinc-700 hover:text-zinc-950 hover:bg-zinc-50'
            }`}
          >
            Gemini Remover
          </a>
          <a
            href="/resizer"
            onClick={(e) => handleLinkClick(e, 'resizer', 'resizer-tool')}
            className={`px-3 py-2.5 min-h-[44px] flex items-center text-sm rounded-lg transition-colors ${
              activePage === 'resizer'
                ? 'font-semibold text-blue-600 bg-blue-50/70'
                : 'font-medium text-zinc-700 hover:text-zinc-950 hover:bg-zinc-50'
            }`}
          >
            Media Resizer
          </a>
          <a
            href="#how-it-works"
            onClick={(e) => handleLinkClick(e, activePage, 'how-it-works')}
            className="px-3 py-2.5 min-h-[44px] flex items-center text-sm font-medium text-zinc-700 hover:text-zinc-950 hover:bg-zinc-50 rounded-lg transition-colors"
          >
            How It Works
          </a>
          <a
            href="#faq"
            onClick={(e) => handleLinkClick(e, activePage, 'faq')}
            className="px-3 py-2.5 min-h-[44px] flex items-center text-sm font-medium text-zinc-700 hover:text-zinc-950 hover:bg-zinc-50 rounded-lg transition-colors"
          >
            FAQ
          </a>
        </nav>
      )}
    </header>
  );
}
