import { useState } from 'react';
import { ArrowUp, ChevronDown } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface HowItWorksAndFaqProps {
  onBackToDownloader: () => void;
}

const STEPS = [
  {
    number: '01',
    title: 'Copy the video link',
    description:
      'Open YouTube, Pinterest, Instagram, Facebook, TikTok, or any website, tap Share, and copy the public post or video URL.',
  },
  {
    number: '02',
    title: 'Paste and analyze',
    description:
      'Paste the link into Audit Video above and tap Get Video. The server resolves redirects and detects all available video and audio streams.',
  },
  {
    number: '03',
    title: 'Pick a format and save',
    description:
      'Choose HD MP4, standard MP4, or MP3 audio. Your browser immediately starts saving the file directly to your Downloads folder or gallery.',
  },
];

const FAQS = [
  {
    q: 'Why do some links fail when the post is private?',
    a: 'Audit Video can only access publicly viewable posts and direct media URLs. Videos inside private accounts, friends-only Facebook groups, or subscriber paywalls are blocked by the host platform without your personal login session.',
  },
  {
    q: 'How do I save downloaded videos on iPhone or Android?',
    a: 'On Android Chrome, files save automatically into your Downloads folder and appear in your Gallery. On iPhone Safari, tap Download in the prompt; once complete, open the Safari Downloads icon, tap the video, and choose Save Video to add it to Photos.',
  },
  {
    q: 'Does HD MP4 include sound?',
    a: 'Yes. Whenever a platform separates high-definition video and audio streams (such as 1080p YouTube or Reddit videos), Audit Video automatically merges both streams together into a single MP4 with audio.',
  },
  {
    q: 'Is there any file size limit or account required?',
    a: 'No account or sign-up is needed. Recent downloads are stored locally in your own browser history only, and you can clear them at any time.',
  },
];

export function HowItWorksAndFaq({ onBackToDownloader }: HowItWorksAndFaqProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <>
      {/* How It Works */}
      <section id="how-it-works" className="py-14 sm:py-20 border-t border-zinc-200 bg-[#FAFAFB]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div className="max-w-xl">
              <h2
                className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-2"
                style={{ textWrap: 'balance' }}
              >
                Three steps from link to saved video
              </h2>
              <p className="text-base text-zinc-600">
                Designed to work smoothly on mobile browsers and desktop screens alike.
              </p>
            </div>
            <button
              type="button"
              onClick={onBackToDownloader}
              className="inline-flex items-center gap-2 px-4 py-2.5 min-h-[44px] text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto cursor-pointer"
            >
              <ArrowUp className="w-4 h-4" aria-hidden="true" />
              <span>Paste a Link Now</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {STEPS.map((step) => (
              <div
                key={step.number}
                className="p-6 bg-white border border-zinc-200 rounded-2xl"
              >
                <span className="font-mono tabular-nums text-sm font-semibold text-blue-600 block mb-3">
                  {step.number}.
                </span>
                <h3 className="font-display text-lg font-bold text-zinc-950 mb-2">{step.title}</h3>
                <p className="text-sm sm:text-base text-zinc-600 leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section id="faq" className="py-14 sm:py-20 border-t border-zinc-200 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2
            className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-8"
            style={{ textWrap: 'balance' }}
          >
            Frequently asked questions
          </h2>

          <div className="divide-y divide-zinc-200 border border-zinc-200 rounded-2xl overflow-hidden bg-white">
            {FAQS.map((item, idx) => {
              const isOpen = openIndex === idx;
              return (
                <div key={item.q}>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setOpenIndex(isOpen ? null : idx)}
                    className="w-full px-5 py-4 min-h-[56px] text-left flex items-center justify-between gap-4 hover:bg-zinc-50 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-blue-600"
                  >
                    <span className="font-display text-sm sm:text-base font-semibold text-zinc-950">
                      {item.q}
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-zinc-500 shrink-0 transition-transform duration-150 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 text-sm sm:text-base text-zinc-600 leading-relaxed">
                      {item.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-zinc-200 bg-[#FAFAFB] py-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2">
              <BrandLogo className="w-6 h-6" />
              <p className="font-display text-base font-bold text-zinc-950">Audit Video</p>
            </div>
            <p className="text-xs text-zinc-500 mt-1.5 max-w-md leading-relaxed">
              Universal web video and audio saver. Please respect creator copyrights and only
              download media you have permission to save for personal offline viewing.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-zinc-600">
            <a href="#downloader" className="hover:text-zinc-950 transition-colors whitespace-nowrap">
              Downloader
            </a>
            <a href="#platforms" className="hover:text-zinc-950 transition-colors whitespace-nowrap">
              Platforms
            </a>
            <a href="#how-it-works" className="hover:text-zinc-950 transition-colors whitespace-nowrap">
              How It Works
            </a>
            <a href="#faq" className="hover:text-zinc-950 transition-colors whitespace-nowrap">
              FAQ
            </a>
          </div>
        </div>
      </footer>
    </>
  );
}
