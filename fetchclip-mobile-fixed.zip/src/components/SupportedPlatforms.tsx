import type { ReactNode } from 'react';
import { Globe } from 'lucide-react';

function YouTubeLogo() {
  return (
    <svg viewBox="0 0 24 24" className="w-6 h-6 shrink-0" aria-hidden="true">
      <path
        fill="#FF0000"
        d="M23.498 6.186a2.99 2.99 0 0 0-2.104-2.118C19.538 3.57 12 3.57 12 3.57s-7.538 0-9.394.498A2.99 2.99 0 0 0 .502 6.186C0 8.05 0 12 0 12s0 3.95.502 5.814a2.99 2.99 0 0 0 2.104 2.118c1.856.498 9.394.498 9.394.498s7.538 0 9.394-.498a2.99 2.99 0 0 0 2.104-2.118C24 15.95 24 12 24 12s0-3.95-.502-5.814Z"
      />
      <path fill="#FFFFFF" d="M9.6 15.568V8.432L15.818 12 9.6 15.568Z" />
    </svg>
  );
}

function PinterestLogo() {
  return (
    <svg viewBox="0 0 24 24" className="w-6 h-6 shrink-0" aria-hidden="true">
      <circle cx="12" cy="12" r="11" fill="#E60023" />
      <path
        fill="#FFFFFF"
        d="M12.2 6.2c-3.5 0-5.4 2.3-5.4 4.7 0 1.2.6 2.5 1.7 2.9.2.1.3 0 .3-.2l.3-1c0-.1 0-.2-.1-.3-.4-.4-.6-1-.6-1.7 0-2 1.5-3.4 3.7-3.4 1.9 0 3.1 1.1 3.1 2.8 0 2.1-1 3.8-2.4 3.8-.7 0-1.3-.6-1.1-1.3.2-.9.6-1.9.6-2.5 0-.6-.3-1.1-1-1.1-.8 0-1.4.8-1.4 1.9 0 .7.2 1.1.2 1.1l-.9 3.9c-.2.9-.1 2 0 2.4 0 .1.1.1.2 0 .2-.2.9-1.1 1.1-1.9l.5-1.8c.3.5 1 .9 1.8.9 2.4 0 4.1-2.2 4.1-5 .1-2.5-2-4.2-4.7-4.2Z"
      />
    </svg>
  );
}

function InstagramLogo() {
  return (
    <svg viewBox="0 0 24 24" className="w-6 h-6 shrink-0" aria-hidden="true">
      <defs>
        <linearGradient id="igGrad" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#FD5949" />
          <stop offset="50%" stopColor="#D6249F" />
          <stop offset="100%" stopColor="#285AEB" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="20" height="20" rx="5.5" fill="url(#igGrad)" />
      <rect
        x="6.2"
        y="6.2"
        width="11.6"
        height="11.6"
        rx="3.4"
        fill="none"
        stroke="#FFFFFF"
        strokeWidth="1.7"
      />
      <circle cx="12" cy="12" r="2.7" fill="none" stroke="#FFFFFF" strokeWidth="1.7" />
      <circle cx="15.8" cy="8.2" r="0.9" fill="#FFFFFF" />
    </svg>
  );
}

function FacebookLogo() {
  return (
    <svg viewBox="0 0 24 24" className="w-6 h-6 shrink-0" aria-hidden="true">
      <circle cx="12" cy="12" r="11" fill="#1877F2" />
      <path
        fill="#FFFFFF"
        d="M15.6 12.7l.4-2.8h-2.7V8.1c0-.8.4-1.5 1.6-1.5h1.2V4.2s-1.1-.2-2.2-.2c-2.2 0-3.7 1.4-3.7 3.8v2.1H7.8v2.8h2.4v7c.5.1 1 .1 1.6.1s1.1 0 1.5-.1v-7h2.3Z"
      />
    </svg>
  );
}

function TikTokLogo() {
  return (
    <svg viewBox="0 0 24 24" className="w-6 h-6 shrink-0" aria-hidden="true">
      <rect x="2" y="2" width="20" height="20" rx="5.5" fill="#09090B" />
      <path
        fill="#25F4EE"
        d="M14.9 6.2c.6.8 1.5 1.3 2.5 1.4v2c-.9 0-1.8-.3-2.5-.8v4.3c0 2.2-1.8 4-4 4a4 4 0 0 1-3.9-4.1c0-2.1 1.7-3.9 3.9-4 .2 0 .5 0 .7.1v2.1a1.9 1.9 0 0 0-.7-.1 1.9 1.9 0 0 0-1.9 1.9c0 1.1.9 1.9 1.9 1.9 1.1 0 1.9-.8 1.9-2V6.2h2.1Z"
      />
      <path
        fill="#FE2C55"
        d="M15.4 6.6c.6.8 1.5 1.3 2.5 1.4v2c-.9 0-1.8-.3-2.5-.8v4.3c0 2.2-1.8 4-4 4a4 4 0 0 1-3.9-4.1c0-2.1 1.7-3.9 3.9-4 .2 0 .5 0 .7.1v2.1a1.9 1.9 0 0 0-.7-.1 1.9 1.9 0 0 0-1.9 1.9c0 1.1.9 1.9 1.9 1.9 1.1 0 1.9-.8 1.9-2V6.6h2.1Z"
        opacity="0.7"
      />
      <path
        fill="#FFFFFF"
        d="M15.15 6.4c.6.8 1.5 1.3 2.5 1.4v2c-.9 0-1.8-.3-2.5-.8v4.3c0 2.2-1.8 4-4 4a4 4 0 0 1-3.9-4.1c0-2.1 1.7-3.9 3.9-4 .2 0 .5 0 .7.1v2.1a1.9 1.9 0 0 0-.7-.1 1.9 1.9 0 0 0-1.9 1.9c0 1.1.9 1.9 1.9 1.9 1.1 0 1.9-.8 1.9-2V6.4h2.1Z"
      />
    </svg>
  );
}

function RedditLogo() {
  return (
    <svg viewBox="0 0 24 24" className="w-6 h-6 shrink-0" aria-hidden="true">
      <circle cx="12" cy="12" r="11" fill="#FF4500" />
      <path
        fill="#FFFFFF"
        d="M18.2 12.1a1.4 1.4 0 0 0-2.4-1c-.9-.6-2.1-1-3.4-1.1l.6-2.7 1.9.4a1 1 0 1 0 .2-.9l-2.3-.5c-.2 0-.4.1-.5.3l-.7 3.3c-1.4 0-2.6.4-3.5 1.1a1.4 1.4 0 1 0-1.5 2.3 2.5 2.5 0 0 0 0 .6c0 2.3 2.5 4.1 5.6 4.1s5.6-1.8 5.6-4.1c0-.2 0-.4-.1-.6.3-.3.5-.7.5-1.2Zm-8.5 1.1a1 1 0 1 1 0-2 1 1 0 0 1 0 2Zm4.7 2.5c-.7.7-1.9.7-2.4.7s-1.7 0-2.4-.7c-.1-.1-.1-.3 0-.4.1-.1.3-.1.4 0 .4.4 1.3.6 2 .6s1.6-.2 2-.6c.1-.1.3-.1.4 0 .1.1.1.3 0 .4Zm-.1-1.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"
      />
    </svg>
  );
}

function VimeoXLogo() {
  return (
    <div className="flex items-center gap-1 shrink-0" aria-hidden="true">
      <svg viewBox="0 0 24 24" className="w-5 h-5">
        <rect x="1.5" y="1.5" width="21" height="21" rx="5" fill="#1AB7EA" />
        <path
          fill="#FFFFFF"
          d="M17.4 9.2c-.1 1.7-1.3 4-3.6 7-2.4 3.1-4.4 4.6-6.1 4.6-1 0-1.9-.9-2.6-2.8l-1.4-5.2c-.5-1.8-1-2.8-1.6-2.8-.1 0-.6.3-1.4.8L0 9.8c.9-.8 1.8-1.6 2.6-2.4 1.2-1 2.1-1.6 2.7-1.6 1.4-.1 2.3.8 2.6 2.9.4 2.2.7 3.6.8 4.1.4 2 .9 3 1.4 3 .4 0 1-.6 1.8-1.9.8-1.3 1.2-2.2 1.3-2.9.1-1.1-.3-1.7-1.3-1.7-.5 0-.9.1-1.4.3.9-3 2.7-4.5 5.3-4.4 1.9.1 2.8 1.3 2.6 3.7Z"
          transform="translate(2.5 1.5) scale(0.8)"
        />
      </svg>
      <svg viewBox="0 0 24 24" className="w-5 h-5">
        <rect x="1.5" y="1.5" width="21" height="21" rx="5" fill="#09090B" />
        <path
          fill="#FFFFFF"
          d="M13.5 10.9 18.2 5.5h-1.1l-4.1 4.7-3.3-4.7H6l4.9 7.1L6 18.5h1.1l4.3-5 3.5 5h3.7l-5.1-7.6Zm-1.5 1.8-.5-.7-4-5.7h1.7l3.2 4.6.5.7 4.2 6h-1.7l-3.4-4.9Z"
        />
      </svg>
    </div>
  );
}

function DirectWebLogo() {
  return (
    <div
      className="w-6 h-6 rounded-md bg-blue-600 text-white flex items-center justify-center shrink-0"
      aria-hidden="true"
    >
      <Globe className="w-3.5 h-3.5" />
    </div>
  );
}

const PLATFORMS: Array<{
  name: string;
  formats: string;
  note: string;
  logo: ReactNode;
}> = [
  {
    name: 'YouTube',
    formats: '1080p HD, 720p, 360p MP4 · 192 kbps MP3',
    note: 'Supports standard watch URLs, Shorts, and youtu.be share links.',
    logo: <YouTubeLogo />,
  },
  {
    name: 'Pinterest',
    formats: '720p / 480p MP4 · HLS-to-MP4 auto conversion',
    note: 'Works with full pin URLs and shortened pin.it links.',
    logo: <PinterestLogo />,
  },
  {
    name: 'Instagram',
    formats: 'Reels, Video Posts, Public Stories MP4 · MP3',
    note: 'Extracts public Reels and feed video links cleanly.',
    logo: <InstagramLogo />,
  },
  {
    name: 'Facebook',
    formats: 'HD & SD MP4 · Public Watch & Reels',
    note: 'Supports facebook.com video links and fb.watch short links.',
    logo: <FacebookLogo />,
  },
  {
    name: 'TikTok',
    formats: 'Watermark-free HD & Standard MP4 · Audio MP3',
    note: 'Works with full TikTok links and vm.tiktok.com URLs.',
    logo: <TikTokLogo />,
  },
  {
    name: 'Reddit',
    formats: 'Muxed Video + Audio MP4 · 128 kbps MP3',
    note: 'Automatically merges separate Reddit video and audio tracks.',
    logo: <RedditLogo />,
  },
  {
    name: 'Vimeo & X',
    formats: 'Progressive HD MP4 · Embedded video streams',
    note: 'Supports public Vimeo videos and X (Twitter) media posts.',
    logo: <VimeoXLogo />,
  },
  {
    name: 'Direct Web Links',
    formats: 'MP4, WebM, MOV, M4V, HLS (.m3u8)',
    note: 'Detects OpenGraph, JSON-LD, and HTML5 video sources on webpages.',
    logo: <DirectWebLogo />,
  },
];

const CAPABILITIES = [
  {
    num: '01',
    title: 'Automatic Audio & Video Merging',
    description:
      'High-definition streams from platforms like YouTube and Reddit often separate video and audio tracks. Audit Video merges them server-side into a single playable MP4 file before saving.',
    span: 'md:col-span-2',
  },
  {
    num: '02',
    title: 'Instant MP3 Audio Extraction',
    description:
      'Need only the soundtrack, podcast clip, or voiceover? Select Audio Track (MP3) on any extracted video to convert and download clean 192 kbps audio.',
    span: 'md:col-span-1',
  },
  {
    num: '03',
    title: 'Direct Browser Save Headers',
    description:
      'Instead of opening raw video streams in a new tab, downloads are streamed with attachment headers so iOS, Android, and desktop browsers save files directly to your device.',
    span: 'md:col-span-1',
  },
  {
    num: '04',
    title: 'Short-Link & HLS Stream Resolution',
    description:
      'Shortened share links (pin.it, fb.watch, youtu.be, vm.tiktok.com) and segmented .m3u8 streams are automatically resolved and remuxed into standard MP4.',
    span: 'md:col-span-2',
  },
];

export function SupportedPlatforms() {
  return (
    <section id="platforms" className="py-14 sm:py-20 border-t border-zinc-200 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-10 sm:mb-12">
          <h2
            className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-zinc-950 mb-3"
            style={{ textWrap: 'balance' }}
          >
            Built for every major video platform and direct web link
          </h2>
          <p className="text-base text-zinc-600 leading-relaxed">
            One clean link box handles social reels, long-form videos, pins, and embedded webpage
            players without browser extensions or extra apps.
          </p>
        </div>

        {/* Platform Directory Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-12 sm:mb-16">
          {PLATFORMS.map((platform) => (
            <div
              key={platform.name}
              className="p-5 bg-[#FAFAFB] border border-zinc-200 rounded-xl flex flex-col justify-between gap-3"
            >
              <div>
                <div className="flex items-center gap-2.5 mb-2">
                  {platform.logo}
                  <h3 className="font-display text-base font-bold text-zinc-950">
                    {platform.name}
                  </h3>
                </div>
                <p className="text-sm text-zinc-600 leading-relaxed">{platform.note}</p>
              </div>
              <p className="font-mono text-xs text-zinc-500 pt-2 border-t border-zinc-200/80">
                {platform.formats}
              </p>
            </div>
          ))}
        </div>

        {/* Asymmetric Capabilities Bento */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {CAPABILITIES.map((cap) => (
            <div
              key={cap.num}
              className={`p-6 bg-white border border-zinc-200 rounded-2xl flex flex-col justify-between gap-4 ${cap.span}`}
            >
              <div>
                <span className="font-mono tabular-nums text-xs font-semibold text-blue-600 block mb-2">
                  {cap.num}.
                </span>
                <h3 className="font-display text-lg font-bold text-zinc-950 mb-2">{cap.title}</h3>
                <p className="text-sm sm:text-base text-zinc-600 leading-relaxed max-w-prose">
                  {cap.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
