export type PlatformId =
  | 'youtube'
  | 'pinterest'
  | 'instagram'
  | 'facebook'
  | 'tiktok'
  | 'twitter'
  | 'reddit'
  | 'vimeo'
  | 'direct'
  | 'web';

export interface MediaFormat {
  id: string;
  label: string;
  quality: string;
  ext: string;
  mimeType: string;
  hasVideo: boolean;
  hasAudio: boolean;
  sizeBytes?: number;
  sizeLabel?: string;
  downloadToken: string;
}

export interface ExtractedMedia {
  id: string;
  platform: PlatformId;
  platformName: string;
  sourceUrl: string;
  resolvedUrl: string;
  title: string;
  author?: string;
  durationSeconds?: number;
  durationLabel?: string;
  thumbnailProxyUrl?: string;
  formats: MediaFormat[];
}

export interface HistoryItem {
  id: string;
  title: string;
  platformName: string;
  sourceUrl: string;
  quality: string;
  ext: string;
  savedAt: string;
}

export interface ProcessedWatermarkResult {
  id: string;
  kind: 'video' | 'image';
  originalName: string;
  cleanFilename: string;
  mimeType: string;
  width: number;
  height: number;
  durationSeconds?: number;
  sizeBytes: number;
  sizeLabel: string;
  previewUrl: string;
  downloadUrl: string;
}

export type AspectRatioOption = 'original' | '16:9' | '9:16' | '1:1' | '4:5' | '4:3';
export type QualityPreset = 'balanced' | 'high' | 'maximum';

export interface ProbedResizeUpload {
  uploadToken: string;
  kind: 'video' | 'image';
  originalName: string;
  mimeType: string;
  width: number;
  height: number;
  aspectRatioLabel: string;
  durationSeconds?: number;
  hasAudio?: boolean;
  sizeBytes: number;
  sizeKb: number;
  sizeMb: number;
  sizeLabel: string;
  previewUrl: string;
}

export interface ResizedMediaResult {
  id: string;
  kind: 'video' | 'image';
  outputFilename: string;
  mimeType: string;
  width: number;
  height: number;
  aspectRatio: AspectRatioOption;
  durationSeconds?: number;
  sizeBytes: number;
  sizeKb: number;
  sizeMb: number;
  sizeLabel: string;
  previewUrl: string;
  downloadUrl: string;
}
