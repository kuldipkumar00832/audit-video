/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { DownloaderWorkspace } from './components/DownloaderWorkspace';
import { GeminiWatermarkRemoverPage } from './components/GeminiWatermarkRemoverPage';
import { Header, type ActivePage } from './components/Header';
import { HowItWorksAndFaq } from './components/HowItWorksAndFaq';
import { MediaResizerPage } from './components/MediaResizerPage';
import { SupportedPlatforms } from './components/SupportedPlatforms';

function getPageFromLocation(): ActivePage {
  if (typeof window === 'undefined') return 'downloader';
  const path = window.location.pathname.toLowerCase();
  const hash = window.location.hash.toLowerCase();
  if (path.includes('watermark-remover') || hash.includes('watermark-remover')) {
    return 'watermark-remover';
  }
  if (path.includes('resizer') || hash.includes('resizer')) {
    return 'resizer';
  }
  return 'downloader';
}

export default function App() {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const watermarkFileInputRef = useRef<HTMLInputElement | null>(null);
  const resizerFileInputRef = useRef<HTMLInputElement | null>(null);
  const [clipboardTrigger, setClipboardTrigger] = useState(0);
  const [activePage, setActivePage] = useState<ActivePage>(() => getPageFromLocation());

  useEffect(() => {
    const handlePopState = () => {
      setActivePage(getPageFromLocation());
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  function navigateToPage(page: ActivePage, sectionId?: string) {
    const targetPath =
      page === 'watermark-remover'
        ? '/watermark-remover'
        : page === 'resizer'
          ? '/resizer'
          : '/';
    if (window.location.pathname !== targetPath) {
      window.history.pushState({}, '', targetPath);
    }
    setActivePage(page);

    if (
      sectionId &&
      sectionId !== 'downloader' &&
      sectionId !== 'watermark-tool' &&
      sectionId !== 'resizer-tool'
    ) {
      window.setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 60);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  function handlePrimaryAction() {
    if (activePage === 'watermark-remover') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      window.setTimeout(() => {
        watermarkFileInputRef.current?.click();
      }, 150);
    } else if (activePage === 'resizer') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      window.setTimeout(() => {
        resizerFileInputRef.current?.click();
      }, 150);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      setClipboardTrigger((prev) => prev + 1);
    }
  }

  function handleBackToDownloader() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    window.setTimeout(() => {
      inputRef.current?.focus();
    }, 250);
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAFB] text-zinc-950">
      <Header
        activePage={activePage}
        onNavigatePage={navigateToPage}
        onPrimaryAction={handlePrimaryAction}
      />
      <main className="flex-1">
        {activePage === 'watermark-remover' ? (
          <GeminiWatermarkRemoverPage
            fileInputRef={watermarkFileInputRef}
            onNavigateDownloader={() => navigateToPage('downloader', 'downloader')}
          />
        ) : activePage === 'resizer' ? (
          <MediaResizerPage
            fileInputRef={resizerFileInputRef}
            onNavigateDownloader={() => navigateToPage('downloader', 'downloader')}
            onNavigateWatermark={() => navigateToPage('watermark-remover', 'watermark-tool')}
          />
        ) : (
          <>
            <DownloaderWorkspace inputRef={inputRef} clipboardTrigger={clipboardTrigger} />
            <SupportedPlatforms />
            <HowItWorksAndFaq onBackToDownloader={handleBackToDownloader} />
          </>
        )}
      </main>
    </div>
  );
}
