import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Readable } from 'node:stream';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express, { type Request, type Response } from 'express';
import {
  createYtdlReadStream,
  extractMediaFromUrl,
  getDownloadJob,
  getThumbnailJob,
} from './server/extractor.ts';
import {
  getWatermarkJob,
  processGeminiWatermarkRemoval,
} from './server/watermark.ts';
import {
  type AspectRatioOption,
  type QualityPreset,
  getResizeOutputJob,
  getResizeSourceJob,
  processMediaResize,
  registerUploadedResizeMedia,
} from './server/resizer.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DESKTOP_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function buildFfmpegHeaderArgs(headers?: Record<string, string>): string[] {
  const args = ['-user_agent', DESKTOP_UA];
  if (headers && Object.keys(headers).length > 0) {
    const formatted = Object.entries(headers)
      .map(([k, v]) => `${k}: ${v}\r\n`)
      .join('');
    args.push('-headers', formatted);
  }
  return args;
}

function encodeContentDisposition(filename: string): string {
  const asciiFallback = filename.replace(/[^\x20-\x7E]/g, '_').replace(/"/g, "'");
  const utf8Encoded = encodeURIComponent(filename);
  return `attachment; filename="${asciiFallback}"; filename*=UTF-8''${utf8Encoded}`;
}

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '64kb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.post('/api/extract', async (req: Request, res: Response) => {
    try {
      const rawUrl = typeof req.body?.url === 'string' ? req.body.url : '';
      if (!rawUrl.trim()) {
        res.status(400).json({ error: 'Please paste a valid video URL.' });
        return;
      }
      const media = await extractMediaFromUrl(rawUrl);
      res.json(media);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Failed to extract video from this link.';
      res.status(422).json({ error: message });
    }
  });

  app.get('/api/thumbnail', async (req: Request, res: Response) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const job = token ? getThumbnailJob(token) : undefined;
    if (!job) {
      res.status(404).end();
      return;
    }

    try {
      const upstream = await fetch(job.url, {
        headers: {
          'User-Agent': DESKTOP_UA,
          ...job.headers,
        },
        signal: AbortSignal.timeout(8000),
      });

      if (!upstream.ok || !upstream.body) {
        res.status(502).end();
        return;
      }

      const contentType = upstream.headers.get('content-type') || 'image/jpeg';
      res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'public, max-age=1800');
      Readable.fromWeb(upstream.body as Parameters<typeof Readable.fromWeb>[0]).pipe(res);
    } catch {
      res.status(502).end();
    }
  });

  app.get('/api/download', async (req: Request, res: Response) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const job = token ? getDownloadJob(token) : undefined;
    if (!job) {
      res.status(404).json({
        error: 'This download link has expired. Please fetch the video link again.',
      });
      return;
    }

    if (job.mode === 'direct') {
      const abortCtrl = new AbortController();
      req.on('close', () => abortCtrl.abort());

      try {
        const forwardHeaders: Record<string, string> = {
          'User-Agent': DESKTOP_UA,
          ...job.headers,
        };
        if (typeof req.headers.range === 'string') {
          forwardHeaders.Range = req.headers.range;
        }

        const upstream = await fetch(job.url, {
          headers: forwardHeaders,
          signal: abortCtrl.signal,
        });

        if (!upstream.ok || !upstream.body) {
          res.status(502).json({
            error: 'Upstream video server refused the download. Please try another quality.',
          });
          return;
        }

        res.status(upstream.status);
        res.setHeader('Content-Disposition', encodeContentDisposition(job.filename));
        res.setHeader('Content-Type', upstream.headers.get('content-type') || job.mimeType);
        res.setHeader('X-Content-Type-Options', 'nosniff');

        const contentLength = upstream.headers.get('content-length');
        if (contentLength) {
          res.setHeader('Content-Length', contentLength);
        }
        const contentRange = upstream.headers.get('content-range');
        if (contentRange) {
          res.setHeader('Content-Range', contentRange);
        }
        const acceptRanges = upstream.headers.get('accept-ranges');
        if (acceptRanges) {
          res.setHeader('Accept-Ranges', acceptRanges);
        }

        const nodeStream = Readable.fromWeb(
          upstream.body as Parameters<typeof Readable.fromWeb>[0]
        );
        nodeStream.on('error', () => {
          if (!res.headersSent) res.status(502).end();
          else res.end();
        });
        nodeStream.pipe(res);
      } catch (err) {
        if (!res.headersSent) {
          const msg = err instanceof Error ? err.message : 'Download stream interrupted.';
          res.status(502).json({ error: msg });
        }
      }
      return;
    }

    if (job.mode === 'ytdl-stream' && job.ytInfo && job.ytFormat) {
      const abortCtrl = new AbortController();
      req.on('close', () => abortCtrl.abort());

      try {
        const stream = createYtdlReadStream(job.ytInfo, job.ytFormat, abortCtrl.signal);
        res.setHeader('Content-Disposition', encodeContentDisposition(job.filename));
        res.setHeader('Content-Type', job.mimeType);
        res.setHeader('X-Content-Type-Options', 'nosniff');
        if (job.ytFormat.contentLength) {
          res.setHeader('Content-Length', String(job.ytFormat.contentLength));
        }
        stream.on('error', () => {
          if (!res.headersSent) res.status(502).json({ error: 'YouTube stream interrupted.' });
          else if (!res.writableEnded) res.end();
        });
        stream.pipe(res);
      } catch (err) {
        if (!res.headersSent) {
          const msg = err instanceof Error ? err.message : 'Unable to stream YouTube format.';
          res.status(502).json({ error: msg });
        }
      }
      return;
    }

    // FFmpeg-backed streaming modes: hls, mux, audio-mp3
    const headerArgs = buildFfmpegHeaderArgs(job.headers);
    let ffmpegArgs: string[] = [];

    if (job.mode === 'hls') {
      ffmpegArgs = [
        '-loglevel',
        'error',
        ...headerArgs,
        '-i',
        job.url,
        '-c',
        'copy',
        '-bsf:a',
        'aac_adtstoasc',
        '-movflags',
        'frag_keyframe+empty_moov',
        '-f',
        'mp4',
        'pipe:1',
      ];
    } else if (job.mode === 'mux' && job.audioUrl) {
      ffmpegArgs = [
        '-loglevel',
        'error',
        ...headerArgs,
        '-i',
        job.url,
        ...headerArgs,
        '-i',
        job.audioUrl,
        '-c:v',
        'copy',
        '-c:a',
        'aac',
        '-shortest',
        '-movflags',
        'frag_keyframe+empty_moov',
        '-f',
        'mp4',
        'pipe:1',
      ];
    } else if (job.mode === 'audio-mp3') {
      ffmpegArgs = [
        '-loglevel',
        'error',
        ...headerArgs,
        '-i',
        job.url,
        '-vn',
        '-acodec',
        'libmp3lame',
        '-ab',
        '192k',
        '-f',
        'mp3',
        'pipe:1',
      ];
    } else {
      res.status(400).json({ error: 'Unsupported download mode.' });
      return;
    }

    const ff = spawn('ffmpeg', ffmpegArgs, { stdio: ['ignore', 'pipe', 'pipe'] });
    let headersSent = false;
    let stderrBuf = '';

    ff.stderr.on('data', (chunk: Buffer) => {
      stderrBuf += chunk.toString();
    });

    ff.stdout.once('data', (firstChunk: Buffer) => {
      headersSent = true;
      res.setHeader('Content-Disposition', encodeContentDisposition(job.filename));
      res.setHeader('Content-Type', job.mimeType);
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.write(firstChunk);
      ff.stdout.pipe(res);
    });

    ff.on('error', () => {
      if (!headersSent && !res.headersSent) {
        res.status(500).json({ error: 'Media processing engine is unavailable.' });
      }
    });

    ff.on('close', (code) => {
      if (!headersSent && !res.headersSent) {
        res.status(502).json({
          error: stderrBuf.trim() || `Media conversion failed (code ${code ?? 'unknown'}).`,
        });
      } else if (!res.writableEnded) {
        res.end();
      }
    });

    req.on('close', () => {
      if (!ff.killed) {
        ff.kill('SIGKILL');
      }
    });
  });

  app.post('/api/remove-watermark', async (req: Request, res: Response) => {
    const MAX_UPLOAD_BYTES = 150 * 1024 * 1024;
    const contentLengthHeader = Number(req.headers['content-length'] || 0);
    if (contentLengthHeader > MAX_UPLOAD_BYTES) {
      res.status(413).json({ error: 'File exceeds the 150 MB upload limit.' });
      return;
    }

    const rawNameHeader =
      typeof req.headers['x-file-name'] === 'string' ? req.headers['x-file-name'] : 'gemini-media';
    let originalName = 'gemini-media';
    try {
      originalName = decodeURIComponent(rawNameHeader) || 'gemini-media';
    } catch {
      originalName = rawNameHeader;
    }

    const incomingMime =
      typeof req.headers['content-type'] === 'string' ? req.headers['content-type'].toLowerCase() : '';
    const ext = path.extname(originalName).toLowerCase() || (incomingMime.startsWith('image/') ? '.png' : '.mp4');

    if (
      !incomingMime.startsWith('video/') &&
      !incomingMime.startsWith('image/') &&
      !/\.(mp4|webm|mov|m4v|mkv|avi|png|jpe?g|webp|bmp)$/i.test(ext)
    ) {
      res.status(400).json({ error: 'Please upload a valid video or image file.' });
      return;
    }

    const tempInputPath = path.join(os.tmpdir(), `fetchclip-up-${crypto.randomUUID()}${ext}`);
    let receivedBytes = 0;
    let aborted = false;

    try {
      await new Promise<void>((resolve, reject) => {
        const ws = fs.createWriteStream(tempInputPath);
        req.on('data', (chunk: Buffer) => {
          receivedBytes += chunk.length;
          if (receivedBytes > MAX_UPLOAD_BYTES && !aborted) {
            aborted = true;
            req.unpipe(ws);
            ws.destroy();
            reject(new Error('File exceeds the 150 MB upload limit.'));
          }
        });
        req.on('error', (err) => {
          ws.destroy();
          reject(err);
        });
        ws.on('error', (err) => reject(err));
        ws.on('finish', () => {
          if (!aborted) resolve();
        });
        req.pipe(ws);
      });

      if (receivedBytes === 0) {
        res.status(400).json({ error: 'Uploaded file is empty.' });
        return;
      }

      const result = await processGeminiWatermarkRemoval(tempInputPath, originalName, incomingMime);
      res.json(result);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Unable to process this file for watermark removal.';
      res.status(422).json({ error: msg });
    } finally {
      fs.promises.unlink(tempInputPath).catch(() => {});
    }
  });

  app.get('/api/watermark-preview', (req: Request, res: Response) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const job = token ? getWatermarkJob(token) : undefined;
    if (!job || !fs.existsSync(job.filePath)) {
      res.status(404).end();
      return;
    }
    res.setHeader('Content-Type', job.mimeType);
    res.setHeader('Cache-Control', 'private, max-age=600');
    res.sendFile(job.filePath);
  });

  app.get('/api/watermark-download', async (req: Request, res: Response) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const job = token ? getWatermarkJob(token) : undefined;
    if (!job || !fs.existsSync(job.filePath)) {
      res.status(404).json({
        error: 'This processed file has expired. Please upload the media again.',
      });
      return;
    }

    try {
      const stat = await fs.promises.stat(job.filePath);
      res.status(200);
      res.setHeader('Content-Disposition', encodeContentDisposition(job.filename));
      res.setHeader('Content-Type', job.mimeType);
      res.setHeader('Content-Length', String(stat.size));
      res.setHeader('Accept-Ranges', 'none');
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      res.setHeader('X-Content-Type-Options', 'nosniff');

      const stream = fs.createReadStream(job.filePath);
      req.on('close', () => {
        if (!res.writableEnded) {
          stream.destroy();
        }
      });
      stream.on('error', () => {
        if (!res.headersSent) {
          res.status(500).json({ error: 'Unable to read processed file.' });
        } else if (!res.writableEnded) {
          res.end();
        }
      });
      stream.pipe(res);
    } catch {
      if (!res.headersSent) {
        res.status(404).json({
          error: 'This processed file has expired. Please upload the media again.',
        });
      }
    }
  });

  app.post('/api/resize-upload', async (req: Request, res: Response) => {
    const MAX_UPLOAD_BYTES = 200 * 1024 * 1024;
    const contentLengthHeader = Number(req.headers['content-length'] || 0);
    if (contentLengthHeader > MAX_UPLOAD_BYTES) {
      res.status(413).json({ error: 'File exceeds the 200 MB upload limit.' });
      return;
    }

    const rawNameHeader =
      typeof req.headers['x-file-name'] === 'string' ? req.headers['x-file-name'] : 'media';
    let originalName = 'media';
    try {
      originalName = decodeURIComponent(rawNameHeader) || 'media';
    } catch {
      originalName = rawNameHeader;
    }

    const incomingMime =
      typeof req.headers['content-type'] === 'string' ? req.headers['content-type'].toLowerCase() : '';
    const ext =
      path.extname(originalName).toLowerCase() || (incomingMime.startsWith('image/') ? '.png' : '.mp4');

    if (
      !incomingMime.startsWith('video/') &&
      !incomingMime.startsWith('image/') &&
      !/\.(mp4|webm|mov|m4v|mkv|avi|png|jpe?g|webp|bmp)$/i.test(ext)
    ) {
      res.status(400).json({ error: 'Please upload a valid video or image file.' });
      return;
    }

    const tempInputPath = path.join(os.tmpdir(), `audit-resize-src-${crypto.randomUUID()}${ext}`);
    let receivedBytes = 0;
    let aborted = false;

    try {
      await new Promise<void>((resolve, reject) => {
        const ws = fs.createWriteStream(tempInputPath);
        req.on('data', (chunk: Buffer) => {
          receivedBytes += chunk.length;
          if (receivedBytes > MAX_UPLOAD_BYTES && !aborted) {
            aborted = true;
            req.unpipe(ws);
            ws.destroy();
            reject(new Error('File exceeds the 200 MB upload limit.'));
          }
        });
        req.on('error', (err) => {
          ws.destroy();
          reject(err);
        });
        ws.on('error', (err) => reject(err));
        ws.on('finish', () => {
          if (!aborted) resolve();
        });
        req.pipe(ws);
      });

      if (receivedBytes === 0) {
        fs.promises.unlink(tempInputPath).catch(() => {});
        res.status(400).json({ error: 'Uploaded file is empty.' });
        return;
      }

      const probed = await registerUploadedResizeMedia(tempInputPath, originalName, incomingMime);
      res.json(probed);
    } catch (err) {
      fs.promises.unlink(tempInputPath).catch(() => {});
      const msg = err instanceof Error ? err.message : 'Unable to read uploaded file.';
      res.status(422).json({ error: msg });
    }
  });

  app.get('/api/resize-source-preview', (req: Request, res: Response) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const job = token ? getResizeSourceJob(token) : undefined;
    if (!job || !fs.existsSync(job.filePath)) {
      res.status(404).end();
      return;
    }
    res.setHeader('Content-Type', job.mimeType);
    res.setHeader('Cache-Control', 'private, max-age=600');
    res.sendFile(job.filePath);
  });

  app.post('/api/resize-process', async (req: Request, res: Response) => {
    try {
      const uploadToken = typeof req.body?.uploadToken === 'string' ? req.body.uploadToken : '';
      const aspectRatio = (
        typeof req.body?.aspectRatio === 'string' ? req.body.aspectRatio : 'original'
      ) as AspectRatioOption;
      const scalePercent = Number(req.body?.scalePercent ?? 100);
      const audioClarity = Number(req.body?.audioClarity ?? 0);
      const targetKb =
        req.body?.targetKb !== undefined ? Number(req.body.targetKb) : undefined;
      const targetMb = Number(req.body?.targetMb ?? 1);
      const quality = (
        typeof req.body?.quality === 'string' ? req.body.quality : 'high'
      ) as QualityPreset;

      if (!uploadToken) {
        res.status(400).json({ error: 'Please upload a video or image first.' });
        return;
      }

      const result = await processMediaResize({
        uploadToken,
        aspectRatio,
        scalePercent,
        audioClarity,
        targetKb,
        targetMb,
        quality,
      });
      res.json(result);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to resize this media file.';
      res.status(422).json({ error: msg });
    }
  });

  app.get('/api/resize-preview', (req: Request, res: Response) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const job = token ? getResizeOutputJob(token) : undefined;
    if (!job || !fs.existsSync(job.filePath)) {
      res.status(404).end();
      return;
    }
    res.setHeader('Content-Type', job.mimeType);
    res.setHeader('Cache-Control', 'private, max-age=600');
    res.sendFile(job.filePath);
  });

  app.get('/api/resize-download', async (req: Request, res: Response) => {
    const token = typeof req.query.token === 'string' ? req.query.token : '';
    const job = token ? getResizeOutputJob(token) : undefined;
    if (!job || !fs.existsSync(job.filePath)) {
      res.status(404).json({
        error: 'This resized file has expired. Please resize the file again.',
      });
      return;
    }

    try {
      const stat = await fs.promises.stat(job.filePath);
      res.status(200);
      res.setHeader('Content-Disposition', encodeContentDisposition(job.filename));
      res.setHeader('Content-Type', job.mimeType);
      res.setHeader('Content-Length', String(stat.size));
      res.setHeader('Accept-Ranges', 'none');
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
      res.setHeader('X-Content-Type-Options', 'nosniff');

      const stream = fs.createReadStream(job.filePath);
      req.on('close', () => {
        if (!res.writableEnded) {
          stream.destroy();
        }
      });
      stream.on('error', () => {
        if (!res.headersSent) {
          res.status(500).json({ error: 'Unable to read resized file.' });
        } else if (!res.writableEnded) {
          res.end();
        }
      });
      stream.pipe(res);
    } catch {
      if (!res.headersSent) {
        res.status(404).json({
          error: 'This resized file has expired. Please resize the file again.',
        });
      }
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const publicDir = path.resolve(__dirname, 'public');
    if (fs.existsSync(publicDir)) {
      app.use(express.static(publicDir));
    }
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`FetchClip server listening on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start FetchClip server:', err);
  process.exit(1);
});
