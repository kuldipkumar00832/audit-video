import crypto from 'node:crypto';
import dns from 'node:dns/promises';
import net from 'node:net';
import { Ytdl, type VideoFormat, type VideoInfo } from '@distube/ytdl-core';
import * as cheerio from 'cheerio';

const ytdl = new Ytdl();

export function createYtdlReadStream(info: VideoInfo, format: VideoFormat, signal?: AbortSignal) {
  return ytdl.download(info, { format, signal });
}

export type PlatformId =
  | 'youtube'
  | 'pinterest'
  | 'instagram'
  | 'facebook'
  | 'tiktok'
  | 'twitter'
  | 'reddit'
  | 'vimeo'
  | 'direct'
  | 'web';

export type DownloadMode = 'direct' | 'hls' | 'mux' | 'audio-mp3' | 'ytdl-stream';

export interface MediaFormat {
  id: string;
  label: string;
  quality: string;
  ext: string;
  mimeType: string;
  hasVideo: boolean;
  hasAudio: boolean;
  sizeBytes?: number;
  sizeLabel?: string;
  downloadToken: string;
}

export interface ExtractedMedia {
  id: string;
  platform: PlatformId;
  platformName: string;
  sourceUrl: string;
  resolvedUrl: string;
  title: string;
  author?: string;
  durationSeconds?: number;
  durationLabel?: string;
  thumbnailProxyUrl?: string;
  formats: MediaFormat[];
}

export interface DownloadJob {
  mode: DownloadMode;
  url: string;
  audioUrl?: string;
  ytInfo?: VideoInfo;
  ytFormat?: VideoFormat;
  headers?: Record<string, string>;
  filename: string;
  mimeType: string;
  ext: string;
  createdAt: number;
}

export interface ThumbnailJob {
  url: string;
  headers?: Record<string, string>;
  createdAt: number;
}

const JOB_TTL_MS = 30 * 60 * 1000;
const MAX_JOBS = 600;
const downloadJobs = new Map<string, DownloadJob>();
const thumbnailJobs = new Map<string, ThumbnailJob>();

const DESKTOP_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function cleanupJobs() {
  const now = Date.now();
  for (const [key, job] of downloadJobs.entries()) {
    if (now - job.createdAt > JOB_TTL_MS) {
      downloadJobs.delete(key);
    }
  }
  for (const [key, job] of thumbnailJobs.entries()) {
    if (now - job.createdAt > JOB_TTL_MS) {
      thumbnailJobs.delete(key);
    }
  }
  if (downloadJobs.size > MAX_JOBS) {
    const excess = downloadJobs.size - MAX_JOBS;
    let count = 0;
    for (const key of downloadJobs.keys()) {
      downloadJobs.delete(key);
      count += 1;
      if (count >= excess) break;
    }
  }
}

export function getDownloadJob(token: string): DownloadJob | undefined {
  cleanupJobs();
  return downloadJobs.get(token);
}

export function getThumbnailJob(token: string): ThumbnailJob | undefined {
  cleanupJobs();
  return thumbnailJobs.get(token);
}

function registerDownloadJob(job: Omit<DownloadJob, 'createdAt'>): string {
  cleanupJobs();
  const token = crypto.randomBytes(20).toString('hex');
  downloadJobs.set(token, { ...job, createdAt: Date.now() });
  return token;
}

function registerThumbnailJob(url: string, headers?: Record<string, string>): string | undefined {
  if (!url) return undefined;
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return undefined;
  } catch {
    return undefined;
  }
  cleanupJobs();
  const token = crypto.randomBytes(16).toString('hex');
  thumbnailJobs.set(token, { url, headers, createdAt: Date.now() });
  return `/api/thumbnail?token=${token}`;
}

function isPrivateIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const parts = ip.split('.').map(Number);
    if (parts.length !== 4 || parts.some((n) => Number.isNaN(n))) return true;
    const [a, b] = parts;
    if (a === 0 || a === 10 || a === 127) return true;
    if (a === 169 && b === 254) return true;
    if (a === 172 && b >= 16 && b <= 31) return true;
    if (a === 192 && b === 168) return true;
    if (a === 100 && b >= 64 && b <= 127) return true;
    return false;
  }
  if (net.isIPv6(ip)) {
    const norm = ip.toLowerCase();
    if (norm === '::1' || norm === '::') return true;
    if (norm.startsWith('fc') || norm.startsWith('fd') || norm.startsWith('fe80')) return true;
    if (norm.startsWith('::ffff:')) {
      return isPrivateIp(norm.replace('::ffff:', ''));
    }
    return false;
  }
  return true;
}

export async function assertSafeUrl(rawUrl: string): Promise<URL> {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error('Please enter a valid video URL starting with https:// or http://.');
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Only HTTP and HTTPS video links are supported.');
  }

  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host.endsWith('.localhost')
  ) {
    throw new Error('Local and private network URLs are not permitted.');
  }

  if (net.isIP(host)) {
    if (isPrivateIp(host)) {
      throw new Error('Private IP addresses are not permitted.');
    }
    return parsed;
  }

  try {
    const records = await dns.lookup(host, { all: true });
    if (!records.length || records.some((r) => isPrivateIp(r.address))) {
      throw new Error('Unable to resolve a public host for this link.');
    }
  } catch (err) {
    if (err instanceof Error && err.message.includes('public host')) {
      throw err;
    }
    throw new Error('Could not reach the host for that URL. Please double-check the link.');
  }

  return parsed;
}

async function resolveFinalUrl(inputUrl: string): Promise<string> {
  let currentUrl = inputUrl;
  for (let hop = 0; hop < 5; hop++) {
    const parsed = await assertSafeUrl(currentUrl);
    // Avoid pre-HEADing YouTube/Reddit/Vimeo full links unless it's a known shortener
    const host = parsed.hostname.toLowerCase();
    const isShortener =
      host === 'pin.it' ||
      host === 'youtu.be' ||
      host === 'fb.watch' ||
      host === 'vm.tiktok.com' ||
      host === 'vt.tiktok.com' ||
      host === 't.co' ||
      host === 'redd.it' ||
      host === 'instagr.am' ||
      host.includes('bit.ly') ||
      host.includes('tinyurl.com') ||
      host.includes('share.google');

    if (!isShortener && hop === 0) {
      return currentUrl;
    }

    try {
      const res = await fetch(currentUrl, {
        method: 'GET',
        redirect: 'manual',
        headers: {
          'User-Agent': DESKTOP_UA,
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
        signal: AbortSignal.timeout(7000),
      });

      const location = res.headers.get('location');
      // Cancel body immediately so socket closes cleanly
      await res.body?.cancel().catch(() => {});

      if (location && res.status >= 300 && res.status < 400) {
        currentUrl = new URL(location, currentUrl).toString();
        continue;
      }
      return currentUrl;
    } catch {
      return currentUrl;
    }
  }
  return currentUrl;
}

export function detectPlatform(urlStr: string): { id: PlatformId; name: string } {
  let host = '';
  try {
    host = new URL(urlStr).hostname.toLowerCase().replace(/^www\./, '');
  } catch {
    return { id: 'web', name: 'Web Video' };
  }

  if (host.includes('youtube.com') || host === 'youtu.be' || host === 'm.youtube.com') {
    return { id: 'youtube', name: 'YouTube' };
  }
  if (host.includes('pinterest.') || host === 'pin.it') {
    return { id: 'pinterest', name: 'Pinterest' };
  }
  if (host.includes('instagram.com') || host === 'instagr.am') {
    return { id: 'instagram', name: 'Instagram' };
  }
  if (host.includes('facebook.com') || host === 'fb.watch' || host.includes('fb.com')) {
    return { id: 'facebook', name: 'Facebook' };
  }
  if (host.includes('tiktok.com')) {
    return { id: 'tiktok', name: 'TikTok' };
  }
  if (host === 'twitter.com' || host === 'x.com' || host.endsWith('.twitter.com') || host.endsWith('.x.com')) {
    return { id: 'twitter', name: 'X (Twitter)' };
  }
  if (host.includes('reddit.com') || host === 'redd.it') {
    return { id: 'reddit', name: 'Reddit' };
  }
  if (host.includes('vimeo.com')) {
    return { id: 'vimeo', name: 'Vimeo' };
  }

  if (/\.(mp4|webm|mov|m4v|mp3|m4a|ogg)(\?|$)/i.test(urlStr)) {
    return { id: 'direct', name: 'Direct Media' };
  }

  return { id: 'web', name: 'Web Video' };
}

function sanitizeFilename(title: string): string {
  const clean = title
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 72);
  return clean || 'fetchclip-video';
}

function formatBytes(bytes?: number): string | undefined {
  if (!bytes || !Number.isFinite(bytes) || bytes <= 0) return undefined;
  const mb = bytes / (1024 * 1024);
  if (mb >= 1024) {
    return `${(mb / 1024).toFixed(2)} GB`;
  }
  if (mb >= 1) {
    return `${mb.toFixed(1)} MB`;
  }
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function formatDuration(seconds?: number): string | undefined {
  if (!seconds || !Number.isFinite(seconds) || seconds <= 0) return undefined;
  const total = Math.round(seconds);
  const hrs = Math.floor(total / 3600);
  const mins = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  if (hrs > 0) {
    return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${mins}:${String(secs).padStart(2, '0')}`;
}

function unescapeJsonUrl(raw: string): string {
  return raw
    .replace(/\\u0026/gi, '&')
    .replace(/\\u002F/gi, '/')
    .replace(/\\\//g, '/')
    .replace(/&amp;/g, '&')
    .trim();
}

async function probeMediaHead(
  url: string,
  headers?: Record<string, string>
): Promise<{ ok: boolean; contentType: string; contentLength?: number }> {
  try {
    const res = await fetch(url, {
      method: 'HEAD',
      headers: {
        'User-Agent': DESKTOP_UA,
        ...headers,
      },
      signal: AbortSignal.timeout(4500),
    });
    const contentType = (res.headers.get('content-type') || '').toLowerCase();
    const lenRaw = res.headers.get('content-length');
    const contentLength = lenRaw ? Number(lenRaw) : undefined;
    return {
      ok: res.ok,
      contentType,
      contentLength: Number.isFinite(contentLength) ? contentLength : undefined,
    };
  } catch {
    return { ok: false, contentType: '' };
  }
}

async function extractDirectMedia(url: string): Promise<ExtractedMedia | null> {
  const head = await probeMediaHead(url);
  const isVideoExt = /\.(mp4|webm|mov|m4v)(\?|$)/i.test(url);
  const isAudioExt = /\.(mp3|m4a|ogg|wav)(\?|$)/i.test(url);
  const isVideoMime = head.ok && head.contentType.startsWith('video/');
  const isAudioMime = head.ok && head.contentType.startsWith('audio/');
  const isOctetStream = head.ok && head.contentType.includes('octet-stream');

  if (!isVideoExt && !isAudioExt && !isVideoMime && !isAudioMime) {
    return null;
  }

  if ((isVideoExt || isAudioExt) && !head.ok) {
    throw new Error('This media file URL returned an error or is no longer publicly accessible.');
  }

  if (
    head.ok &&
    (head.contentType.includes('text/html') || head.contentType.includes('application/xml'))
  ) {
    return null;
  }

  const parsed = new URL(url);
  const rawName = decodeURIComponent(parsed.pathname.split('/').pop() || 'direct-video');
  const title = sanitizeFilename(rawName.replace(/\.[^.]+$/, '')) || 'Direct Media File';

  const isAudio = isAudioExt || isAudioMime;
  const ext = isAudio
    ? url.match(/\.(mp3|m4a|ogg|wav)/i)?.[1]?.toLowerCase() || 'mp3'
    : url.match(/\.(mp4|webm|mov|m4v)/i)?.[1]?.toLowerCase() || 'mp4';
  const mimeType =
    isVideoMime || isAudioMime
      ? head.contentType
      : isOctetStream || isAudio || isVideoExt
        ? isAudio
          ? `audio/${ext === 'mp3' ? 'mpeg' : ext}`
          : `video/${ext}`
        : isAudio
          ? 'audio/mpeg'
          : 'video/mp4';

  const formats: MediaFormat[] = [
    {
      id: 'direct-source',
      label: isAudio ? `Original Audio (${ext.toUpperCase()})` : `Original Video (${ext.toUpperCase()})`,
      quality: isAudio ? 'Original' : 'Source',
      ext,
      mimeType,
      hasVideo: !isAudio,
      hasAudio: true,
      sizeBytes: head.contentLength,
      sizeLabel: formatBytes(head.contentLength),
      downloadToken: registerDownloadJob({
        mode: 'direct',
        url,
        filename: `${title}.${ext}`,
        mimeType,
        ext,
      }),
    },
  ];

  if (!isAudio) {
    formats.push({
      id: 'direct-mp3',
      label: 'Extract Audio (MP3)',
      quality: '192 kbps',
      ext: 'mp3',
      mimeType: 'audio/mpeg',
      hasVideo: false,
      hasAudio: true,
      downloadToken: registerDownloadJob({
        mode: 'audio-mp3',
        url,
        filename: `${title}.mp3`,
        mimeType: 'audio/mpeg',
        ext: 'mp3',
      }),
    });
  }

  return {
    id: crypto.randomUUID(),
    platform: 'direct',
    platformName: 'Direct Media',
    sourceUrl: url,
    resolvedUrl: url,
    title,
    formats,
  };
}

async function extractYouTube(sourceUrl: string, resolvedUrl: string): Promise<ExtractedMedia> {
  try {
    const info = await ytdl.getInfo(resolvedUrl);
    const details = info.videoDetails;
    const title = sanitizeFilename(details.title || 'YouTube Video');
    const author = details.author?.name || undefined;
    const durationSeconds = Number(details.lengthSeconds) || undefined;
    const thumbs = details.thumbnails || [];
    const bestThumb = thumbs.length > 0 ? thumbs[thumbs.length - 1].url : undefined;

    const formats: MediaFormat[] = [];
    const seenLabels = new Set<string>();

    // 1. Combined MP4 streams (instant direct download or SABR stream)
    const combinedMp4 = info.formats
      .filter((f) => f.hasVideo && f.hasAudio && f.container === 'mp4')
      .sort((a, b) => (b.height || 0) - (a.height || 0));

    for (const fmt of combinedMp4) {
      const quality = fmt.qualityLabel || (fmt.height ? `${fmt.height}p` : 'Standard');
      if (seenLabels.has(quality)) continue;
      seenLabels.add(quality);
      const sizeBytes = fmt.contentLength ? Number(fmt.contentLength) : undefined;
      formats.push({
        id: `yt-combined-${fmt.itag}`,
        label: `MP4 Video (${quality})`,
        quality,
        ext: 'mp4',
        mimeType: 'video/mp4',
        hasVideo: true,
        hasAudio: true,
        sizeBytes,
        sizeLabel: formatBytes(sizeBytes),
        downloadToken: registerDownloadJob(
          fmt.url
            ? {
                mode: 'direct',
                url: fmt.url,
                headers: { Referer: 'https://www.youtube.com/' },
                filename: `${title} (${quality}).mp4`,
                mimeType: 'video/mp4',
                ext: 'mp4',
              }
            : {
                mode: 'ytdl-stream',
                url: resolvedUrl,
                ytInfo: info,
                ytFormat: fmt,
                filename: `${title} (${quality}).mp4`,
                mimeType: 'video/mp4',
                ext: 'mp4',
              }
        ),
      });
    }

    // 2. Adaptive High-Def MP4 (muxed on the fly via ffmpeg when direct URLs are available)
    const bestAudio = info.formats
      .filter((f) => !f.hasVideo && f.hasAudio)
      .sort((a, b) => (b.audioBitrate || 0) - (a.audioBitrate || 0))[0];

    if (bestAudio?.url) {
      const adaptiveVideos = info.formats
        .filter(
          (f) =>
            f.hasVideo &&
            !f.hasAudio &&
            f.container === 'mp4' &&
            Boolean(f.url) &&
            (f.height || 0) >= 720
        )
        .sort((a, b) => (b.height || 0) - (a.height || 0));

      for (const fmt of adaptiveVideos) {
        if (!fmt.url) continue;
        const quality = fmt.qualityLabel || (fmt.height ? `${fmt.height}p` : 'HD');
        if (seenLabels.has(quality)) continue;
        seenLabels.add(quality);

        const videoLen = fmt.contentLength ? Number(fmt.contentLength) : 0;
        const audioLen = bestAudio.contentLength ? Number(bestAudio.contentLength) : 0;
        const estBytes = videoLen && audioLen ? videoLen + audioLen : undefined;

        formats.push({
          id: `yt-mux-${fmt.itag}`,
          label: `MP4 Video (${quality} HD)`,
          quality,
          ext: 'mp4',
          mimeType: 'video/mp4',
          hasVideo: true,
          hasAudio: true,
          sizeBytes: estBytes,
          sizeLabel: estBytes ? `~${formatBytes(estBytes)}` : undefined,
          downloadToken: registerDownloadJob({
            mode: 'mux',
            url: fmt.url,
            audioUrl: bestAudio.url,
            headers: { Referer: 'https://www.youtube.com/' },
            filename: `${title} (${quality}).mp4`,
            mimeType: 'video/mp4',
            ext: 'mp4',
          }),
        });
        if (formats.length >= 5) break;
      }

      // 3. Audio MP3 extraction
      formats.push({
        id: 'yt-mp3',
        label: 'Audio Track (MP3)',
        quality: '192 kbps',
        ext: 'mp3',
        mimeType: 'audio/mpeg',
        hasVideo: false,
        hasAudio: true,
        downloadToken: registerDownloadJob({
          mode: 'audio-mp3',
          url: bestAudio.url,
          headers: { Referer: 'https://www.youtube.com/' },
          filename: `${title}.mp3`,
          mimeType: 'audio/mpeg',
          ext: 'mp3',
        }),
      });
    } else if (bestAudio) {
      // SABR audio fallback (M4A stream)
      formats.push({
        id: 'yt-sabr-audio',
        label: `Audio Track (${bestAudio.container.toUpperCase()})`,
        quality: bestAudio.audioBitrate ? `${bestAudio.audioBitrate} kbps` : 'Audio',
        ext: bestAudio.container || 'm4a',
        mimeType: 'audio/mp4',
        hasVideo: false,
        hasAudio: true,
        downloadToken: registerDownloadJob({
          mode: 'ytdl-stream',
          url: resolvedUrl,
          ytInfo: info,
          ytFormat: bestAudio,
          filename: `${title}.${bestAudio.container || 'm4a'}`,
          mimeType: 'audio/mp4',
          ext: bestAudio.container || 'm4a',
        }),
      });
    }

    if (formats.length === 0) {
      throw new Error('No downloadable YouTube streams were available for this video.');
    }

    return {
      id: crypto.randomUUID(),
      platform: 'youtube',
      platformName: 'YouTube',
      sourceUrl,
      resolvedUrl,
      title: details.title || 'YouTube Video',
      author,
      durationSeconds,
      durationLabel: formatDuration(durationSeconds),
      thumbnailProxyUrl: bestThumb ? registerThumbnailJob(bestThumb) : undefined,
      formats,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unable to extract YouTube video.';
    if (msg.toLowerCase().includes('sign in') || msg.toLowerCase().includes('bot') || msg.includes('403')) {
      throw new Error(
        'YouTube temporarily blocked automated access for this video. Try a different public video or link.'
      );
    }
    throw new Error(`Could not fetch YouTube video: ${msg}`);
  }
}

async function extractPinterest(sourceUrl: string, resolvedUrl: string): Promise<ExtractedMedia> {
  const res = await fetch(resolvedUrl, {
    headers: {
      'User-Agent': DESKTOP_UA,
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
    },
    signal: AbortSignal.timeout(12000),
  });

  if (!res.ok) {
    throw new Error(`Pinterest returned status ${res.status}. Make sure the pin link is public.`);
  }

  const html = await res.text();
  const $ = cheerio.load(html);

  const rawTitle =
    $('meta[property="og:title"]').attr('content') ||
    $('title').text() ||
    'Pinterest Video';
  const title = sanitizeFilename(rawTitle.replace(/\s*\|\s*Pinterest.*$/i, ''));
  const thumb =
    $('meta[property="og:image"]').attr('content') ||
    $('meta[name="twitter:image"]').attr('content') ||
    '';

  const mp4Candidates = new Set<string>();
  const hlsCandidates = new Set<string>();

  const ogVideo =
    $('meta[property="og:video"]').attr('content') ||
    $('meta[property="og:video:secure_url"]').attr('content') ||
    $('meta[property="og:video:url"]').attr('content');
  if (ogVideo) {
    if (ogVideo.includes('.m3u8')) hlsCandidates.add(ogVideo);
    else mp4Candidates.add(ogVideo);
  }

  const mp4Matches = html.match(/https?:\/\/[^"'\s<>\\]+\.mp4(?:\?[^"'\s<>\\]*)?/gi) || [];
  for (const match of mp4Matches) {
    const clean = unescapeJsonUrl(match);
    if (clean.includes('pinimg.com') || !clean.includes('ads')) {
      mp4Candidates.add(clean);
    }
  }

  const hlsMatches = html.match(/https?:\/\/[^"'\s<>\\]+\.m3u8(?:\?[^"'\s<>\\]*)?/gi) || [];
  for (const match of hlsMatches) {
    hlsCandidates.add(unescapeJsonUrl(match));
  }

  const formats: MediaFormat[] = [];
  const mp4List = Array.from(mp4Candidates).slice(0, 4);

  const probed = await Promise.all(
    mp4List.map(async (u) => ({
      url: u,
      head: await probeMediaHead(u, { Referer: 'https://www.pinterest.com/' }),
    }))
  );

  // Prefer largest MP4 first
  probed.sort((a, b) => (b.head.contentLength || 0) - (a.head.contentLength || 0));

  probed.forEach((item, idx) => {
    const is720 = /720p/i.test(item.url);
    const is480 = /480p/i.test(item.url);
    const quality = is720 ? '720p HD' : is480 ? '480p' : idx === 0 ? 'HD' : 'Standard';
    formats.push({
      id: `pin-mp4-${idx}`,
      label: `MP4 Video (${quality})`,
      quality,
      ext: 'mp4',
      mimeType: 'video/mp4',
      hasVideo: true,
      hasAudio: true,
      sizeBytes: item.head.contentLength,
      sizeLabel: formatBytes(item.head.contentLength),
      downloadToken: registerDownloadJob({
        mode: 'direct',
        url: item.url,
        headers: { Referer: 'https://www.pinterest.com/' },
        filename: `${title}.mp4`,
        mimeType: 'video/mp4',
        ext: 'mp4',
      }),
    });
  });

  if (formats.length === 0 && hlsCandidates.size > 0) {
    const hlsUrl = Array.from(hlsCandidates)[0];
    formats.push({
      id: 'pin-hls-mp4',
      label: 'MP4 Video (Converted HD)',
      quality: 'HD',
      ext: 'mp4',
      mimeType: 'video/mp4',
      hasVideo: true,
      hasAudio: true,
      downloadToken: registerDownloadJob({
        mode: 'hls',
        url: hlsUrl,
        headers: { Referer: 'https://www.pinterest.com/' },
        filename: `${title}.mp4`,
        mimeType: 'video/mp4',
        ext: 'mp4',
      }),
    });
  }

  if (formats.length === 0) {
    throw new Error(
      'No video was found on this Pinterest link. It may be an image-only pin or private board.'
    );
  }

  const primaryStream = probed[0]?.url || Array.from(hlsCandidates)[0];
  if (primaryStream) {
    formats.push({
      id: 'pin-mp3',
      label: 'Extract Audio (MP3)',
      quality: '192 kbps',
      ext: 'mp3',
      mimeType: 'audio/mpeg',
      hasVideo: false,
      hasAudio: true,
      downloadToken: registerDownloadJob({
        mode: 'audio-mp3',
        url: primaryStream,
        headers: { Referer: 'https://www.pinterest.com/' },
        filename: `${title}.mp3`,
        mimeType: 'audio/mpeg',
        ext: 'mp3',
      }),
    });
  }

  return {
    id: crypto.randomUUID(),
    platform: 'pinterest',
    platformName: 'Pinterest',
    sourceUrl,
    resolvedUrl,
    title: rawTitle.replace(/\s*\|\s*Pinterest.*$/i, '').trim() || 'Pinterest Video',
    thumbnailProxyUrl: thumb
      ? registerThumbnailJob(thumb, { Referer: 'https://www.pinterest.com/' })
      : undefined,
    formats,
  };
}

async function extractReddit(sourceUrl: string, resolvedUrl: string): Promise<ExtractedMedia> {
  const parsed = new URL(resolvedUrl);
  const cleanPath = parsed.pathname.replace(/\/+$/, '');
  const jsonUrl = `${parsed.origin}${cleanPath}.json`;

  const res = await fetch(jsonUrl, {
    headers: {
      'User-Agent': 'FetchClipMediaBot/1.0 (+https://fetchclip.local)',
      Accept: 'application/json',
    },
    signal: AbortSignal.timeout(10000),
  });

  if (!res.ok) {
    throw new Error(`Reddit returned status ${res.status}. Make sure the post is public.`);
  }

  const data = (await res.json()) as Array<{
    data?: {
      children?: Array<{
        data?: {
          title?: string;
          author?: string;
          thumbnail?: string;
          preview?: { images?: Array<{ source?: { url?: string } }> };
          secure_media?: {
            reddit_video?: {
              fallback_url?: string;
              hls_url?: string;
              height?: number;
              duration?: number;
            };
          };
          crosspost_parent_list?: Array<{
            secure_media?: {
              reddit_video?: {
                fallback_url?: string;
                hls_url?: string;
                height?: number;
                duration?: number;
              };
            };
          }>;
        };
      }>;
    };
  }>;

  const post = data?.[0]?.data?.children?.[0]?.data;
  const redditVideo =
    post?.secure_media?.reddit_video || post?.crosspost_parent_list?.[0]?.secure_media?.reddit_video;

  if (!redditVideo?.fallback_url) {
    throw new Error('No Reddit-hosted video was found in this post.');
  }

  const rawTitle = post?.title || 'Reddit Video';
  const title = sanitizeFilename(rawTitle);
  const videoUrl = unescapeJsonUrl(redditVideo.fallback_url);
  const height = redditVideo.height || 720;
  const quality = `${height}p`;

  const thumbRaw = post?.preview?.images?.[0]?.source?.url || post?.thumbnail || '';
  const thumb = thumbRaw.startsWith('http') ? unescapeJsonUrl(thumbRaw) : '';

  // Check if companion audio stream exists on v.redd.it
  const baseVideoDir = videoUrl.substring(0, videoUrl.lastIndexOf('/'));
  const audioCandidates = [
    `${baseVideoDir}/DASH_AUDIO_128.mp4`,
    `${baseVideoDir}/DASH_audio.mp4`,
    `${baseVideoDir}/CMAF_audio_128.mp4`,
    `${baseVideoDir}/DASH_AUDIO_64.mp4`,
  ];

  let foundAudioUrl: string | undefined;
  for (const candidate of audioCandidates) {
    const head = await probeMediaHead(candidate);
    if (head.ok) {
      foundAudioUrl = candidate;
      break;
    }
  }

  const formats: MediaFormat[] = [];
  if (foundAudioUrl) {
    formats.push({
      id: 'reddit-mux-hd',
      label: `MP4 Video + Audio (${quality})`,
      quality,
      ext: 'mp4',
      mimeType: 'video/mp4',
      hasVideo: true,
      hasAudio: true,
      downloadToken: registerDownloadJob({
        mode: 'mux',
        url: videoUrl,
        audioUrl: foundAudioUrl,
        filename: `${title}.mp4`,
        mimeType: 'video/mp4',
        ext: 'mp4',
      }),
    });
  }

  const videoHead = await probeMediaHead(videoUrl);
  formats.push({
    id: 'reddit-video-only',
    label: foundAudioUrl ? `MP4 Video Only (${quality})` : `MP4 Video (${quality})`,
    quality,
    ext: 'mp4',
    mimeType: 'video/mp4',
    hasVideo: true,
    hasAudio: false,
    sizeBytes: videoHead.contentLength,
    sizeLabel: formatBytes(videoHead.contentLength),
    downloadToken: registerDownloadJob({
      mode: 'direct',
      url: videoUrl,
      filename: `${title}.mp4`,
      mimeType: 'video/mp4',
      ext: 'mp4',
    }),
  });

  if (foundAudioUrl) {
    formats.push({
      id: 'reddit-mp3',
      label: 'Extract Audio (MP3)',
      quality: '128 kbps',
      ext: 'mp3',
      mimeType: 'audio/mpeg',
      hasVideo: false,
      hasAudio: true,
      downloadToken: registerDownloadJob({
        mode: 'audio-mp3',
        url: foundAudioUrl,
        filename: `${title}.mp3`,
        mimeType: 'audio/mpeg',
        ext: 'mp3',
      }),
    });
  }

  return {
    id: crypto.randomUUID(),
    platform: 'reddit',
    platformName: 'Reddit',
    sourceUrl,
    resolvedUrl,
    title: rawTitle,
    author: post?.author ? `u/${post.author}` : undefined,
    durationSeconds: redditVideo.duration,
    durationLabel: formatDuration(redditVideo.duration),
    thumbnailProxyUrl: thumb ? registerThumbnailJob(thumb) : undefined,
    formats,
  };
}

async function extractTikTok(sourceUrl: string, resolvedUrl: string): Promise<ExtractedMedia> {
  // Use TikWM public JSON resolver with clean timeout
  const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(resolvedUrl)}&hd=1`;
  try {
    const res = await fetch(apiUrl, {
      headers: { 'User-Agent': DESKTOP_UA, Accept: 'application/json' },
      signal: AbortSignal.timeout(10000),
    });
    if (res.ok) {
      const json = (await res.json()) as {
        code?: number;
        data?: {
          title?: string;
          duration?: number;
          cover?: string;
          play?: string;
          hdplay?: string;
          wmplay?: string;
          music?: string;
          size?: number;
          hd_size?: number;
          author?: { unique_id?: string; nickname?: string };
        };
      };
      if (json.code === 0 && json.data && (json.data.hdplay || json.data.play)) {
        const d = json.data;
        const rawTitle = d.title?.trim() || 'TikTok Video';
        const title = sanitizeFilename(rawTitle);
        const formats: MediaFormat[] = [];

        if (d.hdplay) {
          formats.push({
            id: 'tt-hd',
            label: 'MP4 Video (No Watermark HD)',
            quality: 'HD',
            ext: 'mp4',
            mimeType: 'video/mp4',
            hasVideo: true,
            hasAudio: true,
            sizeBytes: d.hd_size,
            sizeLabel: formatBytes(d.hd_size),
            downloadToken: registerDownloadJob({
              mode: 'direct',
              url: d.hdplay,
              filename: `${title}-hd.mp4`,
              mimeType: 'video/mp4',
              ext: 'mp4',
            }),
          });
        }
        if (d.play && d.play !== d.hdplay) {
          formats.push({
            id: 'tt-sd',
            label: 'MP4 Video (No Watermark)',
            quality: 'Standard',
            ext: 'mp4',
            mimeType: 'video/mp4',
            hasVideo: true,
            hasAudio: true,
            sizeBytes: d.size,
            sizeLabel: formatBytes(d.size),
            downloadToken: registerDownloadJob({
              mode: 'direct',
              url: d.play,
              filename: `${title}.mp4`,
              mimeType: 'video/mp4',
              ext: 'mp4',
            }),
          });
        }
        if (d.music) {
          formats.push({
            id: 'tt-mp3',
            label: 'Audio Track (MP3)',
            quality: 'Original',
            ext: 'mp3',
            mimeType: 'audio/mpeg',
            hasVideo: false,
            hasAudio: true,
            downloadToken: registerDownloadJob({
              mode: 'direct',
              url: d.music,
              filename: `${title}.mp3`,
              mimeType: 'audio/mpeg',
              ext: 'mp3',
            }),
          });
        }

        return {
          id: crypto.randomUUID(),
          platform: 'tiktok',
          platformName: 'TikTok',
          sourceUrl,
          resolvedUrl,
          title: rawTitle,
          author: d.author?.nickname || d.author?.unique_id,
          durationSeconds: d.duration,
          durationLabel: formatDuration(d.duration),
          thumbnailProxyUrl: d.cover ? registerThumbnailJob(d.cover) : undefined,
          formats,
        };
      }
    }
  } catch {
    // Fall through to HTML scraper
  }

  return extractHtmlMedia(sourceUrl, resolvedUrl, 'tiktok', 'TikTok');
}

async function extractVimeo(sourceUrl: string, resolvedUrl: string): Promise<ExtractedMedia> {
  const idMatch = resolvedUrl.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
  if (idMatch?.[1]) {
    const videoId = idMatch[1];
    try {
      const res = await fetch(`https://player.vimeo.com/video/${videoId}/config`, {
        headers: {
          'User-Agent': DESKTOP_UA,
          Referer: 'https://vimeo.com/',
        },
        signal: AbortSignal.timeout(9000),
      });
      if (res.ok) {
        const cfg = (await res.json()) as {
          video?: {
            title?: string;
            duration?: number;
            owner?: { name?: string };
            thumbs?: Record<string, string>;
          };
          request?: {
            files?: {
              progressive?: Array<{
                url: string;
                quality?: string;
                width?: number;
                height?: number;
                mime?: string;
              }>;
            };
          };
        };

        const files = cfg.request?.files?.progressive || [];
        if (files.length > 0) {
          const rawTitle = cfg.video?.title || `Vimeo Video ${videoId}`;
          const title = sanitizeFilename(rawTitle);
          const sorted = [...files].sort((a, b) => (b.height || 0) - (a.height || 0));
          const thumbMap = cfg.video?.thumbs || {};
          const bestThumb = thumbMap['1280'] || thumbMap['960'] || thumbMap['640'] || Object.values(thumbMap)[0];

          const formats: MediaFormat[] = sorted.map((f, idx) => {
            const quality = f.quality || (f.height ? `${f.height}p` : `Stream ${idx + 1}`);
            return {
              id: `vimeo-${idx}-${quality}`,
              label: `MP4 Video (${quality})`,
              quality,
              ext: 'mp4',
              mimeType: f.mime || 'video/mp4',
              hasVideo: true,
              hasAudio: true,
              downloadToken: registerDownloadJob({
                mode: 'direct',
                url: f.url,
                headers: { Referer: 'https://vimeo.com/' },
                filename: `${title} (${quality}).mp4`,
                mimeType: 'video/mp4',
                ext: 'mp4',
              }),
            };
          });

          return {
            id: crypto.randomUUID(),
            platform: 'vimeo',
            platformName: 'Vimeo',
            sourceUrl,
            resolvedUrl,
            title: rawTitle,
            author: cfg.video?.owner?.name,
            durationSeconds: cfg.video?.duration,
            durationLabel: formatDuration(cfg.video?.duration),
            thumbnailProxyUrl: bestThumb ? registerThumbnailJob(bestThumb) : undefined,
            formats,
          };
        }
      }
    } catch {
      // Fallback to generic HTML extraction
    }
  }
  return extractHtmlMedia(sourceUrl, resolvedUrl, 'vimeo', 'Vimeo');
}

async function extractHtmlMedia(
  sourceUrl: string,
  resolvedUrl: string,
  platformId: PlatformId,
  platformName: string
): Promise<ExtractedMedia> {
  const res = await fetch(resolvedUrl, {
    headers: {
      'User-Agent': DESKTOP_UA,
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'Sec-Fetch-Mode': 'navigate',
    },
    signal: AbortSignal.timeout(12000),
  });

  if (!res.ok) {
    throw new Error(
      `${platformName} returned status ${res.status}. The post may require login or be unavailable.`
    );
  }

  const html = await res.text();
  const $ = cheerio.load(html);

  const rawTitle =
    $('meta[property="og:title"]').attr('content') ||
    $('meta[name="twitter:title"]').attr('content') ||
    $('title').text() ||
    `${platformName} Video`;

  const title = sanitizeFilename(rawTitle);
  const thumb =
    $('meta[property="og:image"]').attr('content') ||
    $('meta[name="twitter:image"]').attr('content') ||
    '';

  const candidates = new Map<string, { quality: string; isHls: boolean }>();

  const addCandidate = (rawUrl: string | undefined, quality: string) => {
    if (!rawUrl) return;
    const clean = unescapeJsonUrl(rawUrl);
    if (!clean.startsWith('http')) return;
    if (/\.(jpg|jpeg|png|webp|gif|svg)(\?|$)/i.test(clean)) return;
    const isHls = /\.m3u8(\?|$)/i.test(clean);
    if (!candidates.has(clean)) {
      candidates.set(clean, { quality, isHls });
    }
  };

  // 1. OpenGraph & Twitter Card video tags
  addCandidate($('meta[property="og:video:secure_url"]').attr('content'), 'HD');
  addCandidate($('meta[property="og:video:url"]').attr('content'), 'HD');
  addCandidate($('meta[property="og:video"]').attr('content'), 'HD');
  addCandidate($('meta[name="twitter:player:stream"]').attr('content'), 'HD');

  // 2. HTML5 <video> and <source> tags
  $('video').each((_, el) => {
    addCandidate($(el).attr('src'), 'Standard');
  });
  $('video source').each((_, el) => {
    addCandidate($(el).attr('src'), $(el).attr('label') || 'Standard');
  });

  // 3. JSON-LD VideoObject
  $('script[type="application/ld+json"]').each((_, el) => {
    const rawJson = $(el).text();
    if (!rawJson) return;
    try {
      const parsed = JSON.parse(rawJson);
      const list = Array.isArray(parsed) ? parsed : [parsed];
      for (const item of list) {
        if (item?.contentUrl) addCandidate(item.contentUrl, 'HD');
        if (item?.video?.contentUrl) addCandidate(item.video.contentUrl, 'HD');
      }
    } catch {
      // Ignore malformed JSON-LD
    }
  });

  // 4. Platform-specific embedded JSON keys (Facebook / Instagram / X / general players)
  const keyPatterns: Array<{ regex: RegExp; quality: string }> = [
    { regex: /"browser_native_hd_url"\s*:\s*"([^"]+)"/gi, quality: 'HD' },
    { regex: /"playable_url_quality_hd"\s*:\s*"([^"]+)"/gi, quality: 'HD' },
    { regex: /"hd_src"\s*:\s*"([^"]+)"/gi, quality: 'HD' },
    { regex: /"hd_src_no_ratelimit"\s*:\s*"([^"]+)"/gi, quality: 'HD' },
    { regex: /"browser_native_sd_url"\s*:\s*"([^"]+)"/gi, quality: 'SD' },
    { regex: /"playable_url"\s*:\s*"([^"]+)"/gi, quality: 'SD' },
    { regex: /"sd_src"\s*:\s*"([^"]+)"/gi, quality: 'SD' },
    { regex: /"video_url"\s*:\s*"([^"]+)"/gi, quality: 'HD' },
    { regex: /"contentUrl"\s*:\s*"([^"]+)"/gi, quality: 'HD' },
  ];

  for (const { regex, quality } of keyPatterns) {
    let m: RegExpExecArray | null;
    while ((m = regex.exec(html)) !== null) {
      addCandidate(m[1], quality);
    }
  }

  // 5. Fallback scan for direct .mp4 links in HTML/scripts
  if (candidates.size === 0) {
    const mp4Matches = html.match(/https?:\/\/[^"'\s<>\\]+\.mp4(?:\?[^"'\s<>\\]*)?/gi) || [];
    for (const match of mp4Matches.slice(0, 5)) {
      addCandidate(match, 'Standard');
    }
  }

  if (candidates.size === 0) {
    throw new Error(
      `No public video stream could be found on this ${platformName} page. Private, age-restricted, or login-walled videos cannot be fetched without account authorization.`
    );
  }

  const refererOrigin = new URL(resolvedUrl).origin + '/';
  const entries = Array.from(candidates.entries()).slice(0, 6);

  const verified = await Promise.all(
    entries.map(async ([url, meta]) => {
      if (meta.isHls) {
        return { url, ...meta, ok: true, contentLength: undefined };
      }
      const head = await probeMediaHead(url, { Referer: refererOrigin });
      const isHtml = head.contentType.includes('text/html');
      return {
        url,
        ...meta,
        ok: head.ok && !isHtml,
        contentLength: head.contentLength,
      };
    })
  );

  const valid = verified.filter((v) => v.ok);
  const chosen = valid.length > 0 ? valid : verified.slice(0, 2);

  const formats: MediaFormat[] = chosen.map((item, idx) => {
    const ext = item.isHls ? 'mp4' : item.url.match(/\.(webm|mov|m4v)/i)?.[1]?.toLowerCase() || 'mp4';
    return {
      id: `${platformId}-${idx}`,
      label: item.isHls ? `MP4 Video (Stream ${item.quality})` : `MP4 Video (${item.quality})`,
      quality: item.quality,
      ext,
      mimeType: ext === 'webm' ? 'video/webm' : 'video/mp4',
      hasVideo: true,
      hasAudio: true,
      sizeBytes: item.contentLength,
      sizeLabel: formatBytes(item.contentLength),
      downloadToken: registerDownloadJob({
        mode: item.isHls ? 'hls' : 'direct',
        url: item.url,
        headers: { Referer: refererOrigin },
        filename: `${title}.${ext}`,
        mimeType: ext === 'webm' ? 'video/webm' : 'video/mp4',
        ext,
      }),
    };
  });

  if (chosen[0]) {
    formats.push({
      id: `${platformId}-mp3`,
      label: 'Extract Audio (MP3)',
      quality: '192 kbps',
      ext: 'mp3',
      mimeType: 'audio/mpeg',
      hasVideo: false,
      hasAudio: true,
      downloadToken: registerDownloadJob({
        mode: 'audio-mp3',
        url: chosen[0].url,
        headers: { Referer: refererOrigin },
        filename: `${title}.mp3`,
        mimeType: 'audio/mpeg',
        ext: 'mp3',
      }),
    });
  }

  return {
    id: crypto.randomUUID(),
    platform: platformId,
    platformName,
    sourceUrl,
    resolvedUrl,
    title: rawTitle.trim() || `${platformName} Video`,
    thumbnailProxyUrl: thumb
      ? registerThumbnailJob(thumb, { Referer: refererOrigin })
      : undefined,
    formats,
  };
}

export async function extractMediaFromUrl(rawInput: string): Promise<ExtractedMedia> {
  const trimmed = rawInput.trim();
  if (!trimmed) {
    throw new Error('Please paste a video URL first.');
  }

  const normalizedInput = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  await assertSafeUrl(normalizedInput);

  const resolvedUrl = await resolveFinalUrl(normalizedInput);
  await assertSafeUrl(resolvedUrl);

  const directResult = await extractDirectMedia(resolvedUrl);
  if (directResult) {
    return directResult;
  }

  const platform = detectPlatform(resolvedUrl);

  switch (platform.id) {
    case 'youtube':
      return extractYouTube(normalizedInput, resolvedUrl);
    case 'pinterest':
      return extractPinterest(normalizedInput, resolvedUrl);
    case 'reddit':
      return extractReddit(normalizedInput, resolvedUrl);
    case 'tiktok':
      return extractTikTok(normalizedInput, resolvedUrl);
    case 'vimeo':
      return extractVimeo(normalizedInput, resolvedUrl);
    default:
      return extractHtmlMedia(normalizedInput, resolvedUrl, platform.id, platform.name);
  }
}
