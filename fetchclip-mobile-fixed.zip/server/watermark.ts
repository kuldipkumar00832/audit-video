import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export type MediaKind = 'video' | 'image';

export interface ProcessedWatermarkResult {
  id: string;
  kind: MediaKind;
  originalName: string;
  cleanFilename: string;
  mimeType: string;
  width: number;
  height: number;
  durationSeconds?: number;
  sizeBytes: number;
  sizeLabel: string;
  previewUrl: string;
  downloadUrl: string;
}

export interface WatermarkJob {
  filePath: string;
  filename: string;
  mimeType: string;
  createdAt: number;
}

const JOB_TTL_MS = 20 * 60 * 1000;
const watermarkJobs = new Map<string, WatermarkJob>();

export function cleanupWatermarkJobs() {
  const now = Date.now();
  for (const [token, job] of watermarkJobs.entries()) {
    if (now - job.createdAt > JOB_TTL_MS) {
      watermarkJobs.delete(token);
      fs.promises.unlink(job.filePath).catch(() => {});
    }
  }
}

export function getWatermarkJob(token: string): WatermarkJob | undefined {
  cleanupWatermarkJobs();
  return watermarkJobs.get(token);
}

function registerWatermarkJob(job: Omit<WatermarkJob, 'createdAt'>): string {
  cleanupWatermarkJobs();
  const token = crypto.randomBytes(20).toString('hex');
  watermarkJobs.set(token, { ...job, createdAt: Date.now() });
  return token;
}

function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  const mb = bytes / (1024 * 1024);
  if (mb >= 1024) return `${(mb / 1024).toFixed(2)} GB`;
  if (mb >= 1) return `${mb.toFixed(1)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function sanitizeBaseName(filename: string): string {
  const base = filename.replace(/\.[^.]+$/, '');
  const clean = base
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, '')
    .replace(/\s+/g, '-')
    .trim()
    .slice(0, 64);
  return clean || 'gemini-media';
}

interface ProbeInfo {
  width: number;
  height: number;
  duration?: number;
  hasAudio: boolean;
  audioCodec?: string;
}

function runCommandBuffer(cmd: string, args: string[]): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    const stdoutChunks: Buffer[] = [];
    const stderrChunks: Buffer[] = [];

    child.stdout.on('data', (chunk: Buffer) => stdoutChunks.push(chunk));
    child.stderr.on('data', (chunk: Buffer) => stderrChunks.push(chunk));
    child.on('error', (err) => reject(err));
    child.on('close', (code) => {
      if (code === 0) {
        resolve(Buffer.concat(stdoutChunks));
      } else {
        reject(new Error(Buffer.concat(stderrChunks).toString() || `${cmd} exited with code ${code}`));
      }
    });
  });
}

async function probeMedia(filePath: string): Promise<ProbeInfo> {
  const buf = await runCommandBuffer('ffprobe', [
    '-v',
    'quiet',
    '-print_format',
    'json',
    '-show_streams',
    '-show_format',
    filePath,
  ]);
  const parsed = JSON.parse(buf.toString()) as {
    streams?: Array<{
      codec_type?: string;
      codec_name?: string;
      width?: number;
      height?: number;
    }>;
    format?: {
      duration?: string;
    };
  };

  const videoStream = parsed.streams?.find((s) => s.codec_type === 'video' && s.width && s.height);
  if (!videoStream?.width || !videoStream?.height) {
    throw new Error('Could not read dimensions from the uploaded file. Please upload a valid video or image.');
  }

  const audioStream = parsed.streams?.find((s) => s.codec_type === 'audio');
  const dur = parsed.format?.duration ? Number(parsed.format.duration) : undefined;

  return {
    width: videoStream.width,
    height: videoStream.height,
    duration: dur && Number.isFinite(dur) ? dur : undefined,
    hasAudio: Boolean(audioStream),
    audioCodec: audioStream?.codec_name,
  };
}

interface DelogoRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

function clampRect(rect: DelogoRect, width: number, height: number): DelogoRect {
  const maxW = Math.max(8, width - 4);
  const maxH = Math.max(8, height - 4);
  const w = Math.max(8, Math.min(rect.w, maxW));
  const h = Math.max(8, Math.min(rect.h, maxH));
  const x = Math.max(1, Math.min(rect.x, width - w - 1));
  const y = Math.max(1, Math.min(rect.y, height - h - 1));
  return { x, y, w, h };
}

/**
 * Automatically locates the Gemini AI watermark in the bottom-right corner
 * by scanning local high-frequency / high-luminance contrast inside the bottom-right
 * corner region, falling back cleanly to Google's canonical Gemini / Veo watermark coordinates.
 */
async function detectGeminiCornerBox(
  filePath: string,
  kind: MediaKind,
  probe: ProbeInfo
): Promise<DelogoRect> {
  const { width, height, duration } = probe;

  // Canonical Gemini / Veo bottom-right corner fallback
  const minDim = Math.min(width, height);
  const fallback: DelogoRect =
    kind === 'image'
      ? (() => {
          const size = Math.max(40, Math.min(132, Math.round(minDim * 0.07)));
          const margin = Math.max(12, Math.min(48, Math.round(minDim * 0.02)));
          return {
            x: width - size - margin,
            y: height - size - margin,
            w: size,
            h: size,
          };
        })()
      : (() => {
          const w = Math.max(88, Math.min(280, Math.round(width * 0.135)));
          const h = Math.max(40, Math.min(115, Math.round(height * 0.08)));
          const mx = Math.max(10, Math.min(40, Math.round(width * 0.015)));
          const my = Math.max(10, Math.min(40, Math.round(height * 0.018)));
          return {
            x: width - w - mx,
            y: height - h - my,
            w,
            h,
          };
        })();

  try {
    // Sample bottom-right 22% x 18% corner into raw RGB24 to refine bounding box
    const roiW = Math.max(32, Math.min(width - 2, Math.round(width * 0.22)));
    const roiH = Math.max(32, Math.min(height - 2, Math.round(height * 0.18)));
    const roiX = width - roiW;
    const roiY = height - roiH;

    const seekTime =
      kind === 'video' && duration && duration > 0.6 ? Math.min(1.5, duration * 0.25) : 0;

    const args: string[] = [];
    if (seekTime > 0) {
      args.push('-ss', seekTime.toFixed(2));
    }
    args.push(
      '-i',
      filePath,
      '-frames:v',
      '1',
      '-vf',
      `crop=${roiW}:${roiH}:${roiX}:${roiY}`,
      '-f',
      'rawvideo',
      '-pix_fmt',
      'rgb24',
      'pipe:1'
    );

    const raw = await runCommandBuffer('ffmpeg', args);
    if (raw.length < roiW * roiH * 3) {
      return clampRect(fallback, width, height);
    }

    // Compute luminance map
    const lum = new Float32Array(roiW * roiH);
    for (let i = 0; i < roiW * roiH; i++) {
      const idx = i * 3;
      lum[i] = 0.299 * raw[idx] + 0.587 * raw[idx + 1] + 0.114 * raw[idx + 2];
    }

    // Detect sharp local contrast spikes typical of the Gemini sparkle / "Veo" watermark
    const radius = 5;
    let minActiveX = roiW;
    let maxActiveX = 0;
    let minActiveY = roiH;
    let maxActiveY = 0;
    let activeCount = 0;

    // Restrict scan to outer corner sub-box where Gemini marks appear
    const scanStartX = Math.floor(roiW * 0.15);
    const scanStartY = Math.floor(roiH * 0.25);

    for (let y = scanStartY; y < roiH - 2; y++) {
      for (let x = scanStartX; x < roiW - 2; x++) {
        let sum = 0;
        let samples = 0;
        for (const dy of [-radius, 0, radius]) {
          for (const dx of [-radius, 0, radius]) {
            if (dx === 0 && dy === 0) continue;
            const nx = Math.max(0, Math.min(roiW - 1, x + dx));
            const ny = Math.max(0, Math.min(roiH - 1, y + dy));
            sum += lum[ny * roiW + nx];
            samples++;
          }
        }
        const localMean = sum / samples;
        const diff = lum[y * roiW + x] - localMean;
        if (Math.abs(diff) > 22) {
          activeCount++;
          if (x < minActiveX) minActiveX = x;
          if (x > maxActiveX) maxActiveX = x;
          if (y < minActiveY) minActiveY = y;
          if (y > maxActiveY) maxActiveY = y;
        }
      }
    }

    if (activeCount >= 18) {
      const detectedW = maxActiveX - minActiveX + 16;
      const detectedH = maxActiveY - minActiveY + 16;
      const maxAllowedW = Math.round(width * (kind === 'image' ? 0.14 : 0.2));
      const maxAllowedH = Math.round(height * (kind === 'image' ? 0.14 : 0.14));

      // Only accept detected box if it is a compact watermark (not noisy full-corner scene texture)
      if (
        detectedW >= 24 &&
        detectedH >= 24 &&
        detectedW <= maxAllowedW &&
        detectedH <= maxAllowedH
      ) {
        return clampRect(
          {
            x: roiX + minActiveX - 8,
            y: roiY + minActiveY - 8,
            w: detectedW,
            h: detectedH,
          },
          width,
          height
        );
      }
    }
  } catch {
    // Fall back silently to canonical Gemini coordinates
  }

  return clampRect(fallback, width, height);
}

export async function processGeminiWatermarkRemoval(
  inputPath: string,
  originalName: string,
  incomingMime: string
): Promise<ProcessedWatermarkResult> {
  const lowerExt = path.extname(originalName).toLowerCase();
  const isImage =
    incomingMime.startsWith('image/') || /\.(png|jpe?g|webp|bmp)$/i.test(lowerExt);
  const kind: MediaKind = isImage ? 'image' : 'video';

  const probe = await probeMedia(inputPath);
  const rect = await detectGeminiCornerBox(inputPath, kind, probe);
  const baseName = sanitizeBaseName(originalName);

  const outExt = isImage ? (lowerExt === '.png' ? 'png' : 'jpg') : 'mp4';
  const outMime = isImage ? (outExt === 'png' ? 'image/png' : 'image/jpeg') : 'video/mp4';
  const cleanFilename = `${baseName}-no-watermark.${outExt}`;
  const outPath = path.join(os.tmpdir(), `fetchclip-clean-${crypto.randomUUID()}.${outExt}`);

  const delogoFilter = `delogo=x=${rect.x}:y=${rect.y}:w=${rect.w}:h=${rect.h}`;

  if (kind === 'image') {
    const args = ['-y', '-i', inputPath, '-vf', delogoFilter];
    if (outExt === 'jpg') {
      args.push('-q:v', '2');
    }
    args.push(outPath);
    await runCommandBuffer('ffmpeg', args);
  } else {
    const args = [
      '-y',
      '-i',
      inputPath,
      '-vf',
      `${delogoFilter},format=yuv420p`,
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      '-crf',
      '19',
      ...(probe.hasAudio
        ? probe.audioCodec === 'aac'
          ? ['-c:a', 'copy']
          : ['-c:a', 'aac', '-b:a', '192k']
        : ['-an']),
      '-movflags',
      '+faststart',
      '-threads',
      '0',
      outPath,
    ];
    await runCommandBuffer('ffmpeg', args);
  }

  const stat = await fs.promises.stat(outPath);
  const token = registerWatermarkJob({
    filePath: outPath,
    filename: cleanFilename,
    mimeType: outMime,
  });

  return {
    id: crypto.randomUUID(),
    kind,
    originalName,
    cleanFilename,
    mimeType: outMime,
    width: probe.width,
    height: probe.height,
    durationSeconds: probe.duration,
    sizeBytes: stat.size,
    sizeLabel: formatBytes(stat.size),
    previewUrl: `/api/watermark-preview?token=${token}`,
    downloadUrl: `/api/watermark-download?token=${token}`,
  };
}
