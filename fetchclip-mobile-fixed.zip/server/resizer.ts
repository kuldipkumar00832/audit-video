import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import zlib from 'node:zlib';

export type ResizerMediaKind = 'video' | 'image';
export type AspectRatioOption = 'original' | '16:9' | '9:16' | '1:1' | '4:5' | '4:3';
export type QualityPreset = 'balanced' | 'high' | 'maximum';

export interface ProbedResizeUpload {
  uploadToken: string;
  kind: ResizerMediaKind;
  originalName: string;
  mimeType: string;
  width: number;
  height: number;
  aspectRatioLabel: string;
  durationSeconds?: number;
  hasAudio?: boolean;
  sizeBytes: number;
  sizeKb: number;
  sizeMb: number;
  sizeLabel: string;
  previewUrl: string;
}

export interface ResizedMediaResult {
  id: string;
  kind: ResizerMediaKind;
  outputFilename: string;
  mimeType: string;
  width: number;
  height: number;
  aspectRatio: AspectRatioOption;
  durationSeconds?: number;
  sizeBytes: number;
  sizeKb: number;
  sizeMb: number;
  sizeLabel: string;
  previewUrl: string;
  downloadUrl: string;
}

export interface ResizeSourceJob {
  filePath: string;
  kind: ResizerMediaKind;
  originalName: string;
  mimeType: string;
  width: number;
  height: number;
  durationSeconds?: number;
  hasAudio: boolean;
  audioCodec?: string;
  sizeBytes: number;
  createdAt: number;
}

export interface ResizeOutputJob {
  filePath: string;
  filename: string;
  mimeType: string;
  createdAt: number;
}

const JOB_TTL_MS = 25 * 60 * 1000;
const sourceJobs = new Map<string, ResizeSourceJob>();
const outputJobs = new Map<string, ResizeOutputJob>();

export function cleanupResizeJobs() {
  const now = Date.now();
  for (const [token, job] of sourceJobs.entries()) {
    if (now - job.createdAt > JOB_TTL_MS) {
      sourceJobs.delete(token);
      fs.promises.unlink(job.filePath).catch(() => {});
    }
  }
  for (const [token, job] of outputJobs.entries()) {
    if (now - job.createdAt > JOB_TTL_MS) {
      outputJobs.delete(token);
      fs.promises.unlink(job.filePath).catch(() => {});
    }
  }
}

export function getResizeSourceJob(token: string): ResizeSourceJob | undefined {
  cleanupResizeJobs();
  return sourceJobs.get(token);
}

export function getResizeOutputJob(token: string): ResizeOutputJob | undefined {
  cleanupResizeJobs();
  return outputJobs.get(token);
}

function registerResizeOutputJob(job: Omit<ResizeOutputJob, 'createdAt'>): string {
  cleanupResizeJobs();
  const token = crypto.randomBytes(20).toString('hex');
  outputJobs.set(token, { ...job, createdAt: Date.now() });
  return token;
}

function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  const mb = bytes / (1024 * 1024);
  if (mb >= 1024) return `${(mb / 1024).toFixed(2)} GB`;
  if (mb >= 1) return `${mb.toFixed(2)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function sanitizeBaseName(filename: string): string {
  const base = filename.replace(/\.[^.]+$/, '');
  const clean = base
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, '')
    .replace(/\s+/g, '-')
    .trim()
    .slice(0, 64);
  return clean || 'resized-media';
}

function computeGcd(a: number, b: number): number {
  let x = Math.abs(a);
  let y = Math.abs(b);
  while (y !== 0) {
    const t = y;
    y = x % y;
    x = t;
  }
  return x || 1;
}

function formatAspectRatio(w: number, h: number): string {
  const ratio = w / h;
  const known: Array<[string, number]> = [
    ['16:9', 16 / 9],
    ['9:16', 9 / 16],
    ['1:1', 1],
    ['4:5', 4 / 5],
    ['4:3', 4 / 3],
    ['3:4', 3 / 4],
  ];
  for (const [label, target] of known) {
    if (Math.abs(ratio - target) < 0.03) return label;
  }
  const g = computeGcd(w, h);
  const rw = Math.round(w / g);
  const rh = Math.round(h / g);
  if (rw <= 25 && rh <= 25) return `${rw}:${rh}`;
  return `${ratio.toFixed(2)}:1`;
}

function runCommandBuffer(cmd: string, args: string[]): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    const stdoutChunks: Buffer[] = [];
    const stderrChunks: Buffer[] = [];

    child.stdout.on('data', (chunk: Buffer) => stdoutChunks.push(chunk));
    child.stderr.on('data', (chunk: Buffer) => stderrChunks.push(chunk));
    child.on('error', (err) => reject(err));
    child.on('close', (code) => {
      if (code === 0) {
        resolve(Buffer.concat(stdoutChunks));
      } else {
        reject(new Error(Buffer.concat(stderrChunks).toString() || `${cmd} exited with code ${code}`));
      }
    });
  });
}

export async function registerUploadedResizeMedia(
  filePath: string,
  originalName: string,
  incomingMime: string
): Promise<ProbedResizeUpload> {
  cleanupResizeJobs();

  const buf = await runCommandBuffer('ffprobe', [
    '-v',
    'quiet',
    '-print_format',
    'json',
    '-show_streams',
    '-show_format',
    filePath,
  ]);
  const parsed = JSON.parse(buf.toString()) as {
    streams?: Array<{
      codec_type?: string;
      codec_name?: string;
      width?: number;
      height?: number;
    }>;
    format?: {
      duration?: string;
    };
  };

  const videoStream = parsed.streams?.find((s) => s.codec_type === 'video' && s.width && s.height);
  if (!videoStream?.width || !videoStream?.height) {
    throw new Error('Could not read dimensions from this file. Please upload a valid video or image.');
  }

  const lowerExt = path.extname(originalName).toLowerCase();
  const isImage =
    incomingMime.startsWith('image/') || /\.(png|jpe?g|webp|bmp)$/i.test(lowerExt);
  const kind: ResizerMediaKind = isImage ? 'image' : 'video';

  const audioStream = parsed.streams?.find((s) => s.codec_type === 'audio');
  const dur = parsed.format?.duration ? Number(parsed.format.duration) : undefined;
  const stat = await fs.promises.stat(filePath);
  const mimeType = isImage
    ? lowerExt === '.png'
      ? 'image/png'
      : lowerExt === '.webp'
        ? 'image/webp'
        : 'image/jpeg'
    : incomingMime.startsWith('video/')
      ? incomingMime
      : 'video/mp4';

  const uploadToken = crypto.randomBytes(20).toString('hex');
  sourceJobs.set(uploadToken, {
    filePath,
    kind,
    originalName,
    mimeType,
    width: videoStream.width,
    height: videoStream.height,
    durationSeconds: !isImage && dur && Number.isFinite(dur) ? dur : undefined,
    hasAudio: Boolean(audioStream),
    audioCodec: audioStream?.codec_name,
    sizeBytes: stat.size,
    createdAt: Date.now(),
  });

  const sizeKb = Number((stat.size / 1024).toFixed(2));
  const sizeMb = Number((stat.size / (1024 * 1024)).toFixed(3));

  return {
    uploadToken,
    kind,
    originalName,
    mimeType,
    width: videoStream.width,
    height: videoStream.height,
    aspectRatioLabel: formatAspectRatio(videoStream.width, videoStream.height),
    durationSeconds: !isImage && dur && Number.isFinite(dur) ? dur : undefined,
    hasAudio: !isImage ? Boolean(audioStream) : false,
    sizeBytes: stat.size,
    sizeKb,
    sizeMb,
    sizeLabel: formatBytes(stat.size),
    previewUrl: `/api/resize-source-preview?token=${uploadToken}`,
  };
}

function evenDim(n: number): number {
  return Math.max(8, Math.floor(n / 2) * 2);
}

function resolveTargetDimensions(
  srcW: number,
  srcH: number,
  aspect: AspectRatioOption,
  scalePercent: number
): { targetW: number; targetH: number } {
  const ratioMap: Record<Exclude<AspectRatioOption, 'original'>, number> = {
    '16:9': 16 / 9,
    '9:16': 9 / 16,
    '1:1': 1,
    '4:5': 4 / 5,
    '4:3': 4 / 3,
  };

  let baseW = srcW;
  let baseH = srcH;

  if (aspect !== 'original') {
    const targetRatio = ratioMap[aspect];
    const srcRatio = srcW / srcH;
    if (srcRatio > targetRatio) {
      // Source is wider -> crop width to match target ratio
      baseH = srcH;
      baseW = Math.round(srcH * targetRatio);
    } else {
      // Source is taller -> crop height to match target ratio
      baseW = srcW;
      baseH = Math.round(srcW / targetRatio);
    }
  }

  const factor = Math.max(0.02, Math.min(2.0, scalePercent / 100));
  return {
    targetW: evenDim(baseW * factor),
    targetH: evenDim(baseH * factor),
  };
}

function buildCropScaleFilter(
  srcW: number,
  srcH: number,
  targetW: number,
  targetH: number,
  aspect: AspectRatioOption
): string {
  if (aspect === 'original') {
    return `scale=${targetW}:${targetH}:flags=lanczos`;
  }
  const ratioMap: Record<Exclude<AspectRatioOption, 'original'>, number> = {
    '16:9': 16 / 9,
    '9:16': 9 / 16,
    '1:1': 1,
    '4:5': 4 / 5,
    '4:3': 4 / 3,
  };
  const targetRatio = ratioMap[aspect];
  const srcRatio = srcW / srcH;
  let cropW = srcW;
  let cropH = srcH;
  if (srcRatio > targetRatio) {
    cropH = evenDim(srcH);
    cropW = evenDim(srcH * targetRatio);
  } else {
    cropW = evenDim(srcW);
    cropH = evenDim(srcW / targetRatio);
  }
  return `crop=${cropW}:${cropH},scale=${targetW}:${targetH}:flags=lanczos`;
}

/**
 * Builds an adaptive studio voice restoration chain from audioClarity (0..100):
 * repairs clipping/distortion, suppresses broadband & low-frequency room noise,
 * clarifies speech presence, normalizes vocal dynamics, and prevents peaking.
 */
function buildVoiceEnhancementFilter(audioClarity: number): string | null {
  const strength = Math.max(0, Math.min(100, Math.round(audioClarity)));
  if (strength <= 0) return null;

  const t = strength / 100;
  const hpFreq = Math.round(70 + t * 22); // 70Hz..92Hz rumble & 50/60Hz hum cut
  const lpFreq = Math.round(15000 - t * 3000); // 15kHz..12kHz harsh hiss trim
  const nrDb = (12 + t * 24).toFixed(1); // 12dB..36dB FFT denoise
  const nfDb = Math.round(-34 + t * 14); // -34dB..-20dB noise floor sensitivity
  const gateThresh = (0.025 + t * 0.045).toFixed(3); // 0.025..0.070 soft gate threshold
  const gateRange = Math.max(0.08, 0.38 - t * 0.3).toFixed(2); // 0.38..0.08 downward noise floor trim
  const mudGain = (-0.8 - t * 2.0).toFixed(2); // de-mud 360Hz
  const bodyGain = (0.6 + t * 1.2).toFixed(2); // warm vocal body 165Hz
  const presenceGain = (0.9 + t * 2.2).toFixed(2); // speech intelligibility 3.1kHz
  const compRatio = (1.6 + t * 1.2).toFixed(1);
  const makeup = (1.0 + t * 0.7).toFixed(2);

  const stages: string[] = [];
  // Repair clipped/distorted waveforms and clicks first before spectral filtering
  if (strength >= 25) {
    stages.push('adeclip=w=55:o=75:t=8:m=a');
  }
  if (strength >= 50) {
    stages.push('adeclick=w=55:o=75:t=2.2');
  }

  stages.push(
    `highpass=f=${hpFreq}`,
    `lowpass=f=${lpFreq}`,
    `afftdn=nr=${nrDb}:nf=${nfDb}:tn=1`,
    `agate=threshold=${gateThresh}:ratio=4:range=${gateRange}:attack=12:release=160:knee=4`,
    `equalizer=f=360:t=q:w=1.2:g=${mudGain}`,
    `equalizer=f=165:t=q:w=1.1:g=${bodyGain}`,
    `equalizer=f=3100:t=q:w=1.3:g=${presenceGain}`,
    `acompressor=threshold=-16dB:ratio=${compRatio}:attack=8:release=120:makeup=${makeup}`,
    'alimiter=limit=0.92:attack=5:release=60:level=0'
  );

  return stages.join(',');
}

/**
 * Pads a valid JPEG using spec-compliant APP15 (0xFF 0xEF) segments right before EOI (0xFF 0xD9)
 * so the resulting file opens normally in all browsers/apps while matching the requested target MB.
 */
async function padJpegToTargetSize(filePath: string, targetBytes: number): Promise<void> {
  const data = await fs.promises.readFile(filePath);
  if (data.length >= targetBytes || data.length < 4) return;
  if (data[data.length - 2] !== 0xff || data[data.length - 1] !== 0xd9) return;

  const needed = targetBytes - data.length;
  const segments: Buffer[] = [data.subarray(0, data.length - 2)];
  let remaining = needed;

  while (remaining > 0) {
    // Each APP15 marker has 2 bytes marker (FF EF) + 2 bytes length + payload
    // Max segment payload = 65531 bytes (length field = payload + 2 = 65533)
    if (remaining <= 4) break;
    const chunkPayload = Math.min(remaining - 4, 65520);
    const seg = Buffer.alloc(chunkPayload + 4);
    seg[0] = 0xff;
    seg[1] = 0xef;
    seg.writeUInt16BE(chunkPayload + 2, 2);
    // Fill with harmless space bytes
    seg.fill(0x20, 4);
    segments.push(seg);
    remaining -= chunkPayload + 4;
  }

  segments.push(Buffer.from([0xff, 0xd9]));
  await fs.promises.writeFile(filePath, Buffer.concat(segments));
}

/**
 * Pads a valid PNG using a spec-compliant tEXt metadata chunk right before IEND
 * with a valid CRC32 checksum.
 */
async function padPngToTargetSize(filePath: string, targetBytes: number): Promise<void> {
  const data = await fs.promises.readFile(filePath);
  if (data.length >= targetBytes || data.length < 20) return;

  // Locate final IEND chunk (12 bytes: 00 00 00 00 'I' 'E' 'N' 'D' AE 42 60 82)
  const iendOffset = data.lastIndexOf(Buffer.from('IEND'));
  if (iendOffset < 4) return;
  const chunkStart = iendOffset - 4;
  let remaining = targetBytes - data.length;
  if (remaining <= 24) return;

  const parts: Buffer[] = [data.subarray(0, chunkStart)];
  const prefix = Buffer.from('padding\0', 'ascii');
  const maxChunkTotal = 4 * 1024 * 1024;

  while (remaining > 24) {
    const chunkTotal = Math.min(remaining, maxChunkTotal);
    const payloadLen = chunkTotal - 12; // 4 len + 4 type + payload + 4 crc
    const payload = Buffer.alloc(payloadLen, 0x20);
    prefix.copy(payload, 0);

    const typeAndData = Buffer.alloc(4 + payloadLen);
    typeAndData.write('tEXt', 0, 'ascii');
    payload.copy(typeAndData, 4);

    const lenBuf = Buffer.alloc(4);
    lenBuf.writeUInt32BE(payloadLen, 0);

    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(zlib.crc32(typeAndData) >>> 0, 0);

    parts.push(lenBuf, typeAndData, crcBuf);
    remaining -= chunkTotal;
  }

  parts.push(data.subarray(chunkStart));
  await fs.promises.writeFile(filePath, Buffer.concat(parts));
}

async function resizeImageToTarget(
  src: ResizeSourceJob,
  aspect: AspectRatioOption,
  scalePercent: number,
  targetBytesInput: number,
  quality: QualityPreset
): Promise<ResizedMediaResult> {
  const targetBytes = Math.max(2 * 1024, Math.round(targetBytesInput));
  let currentScale = scalePercent;
  let dims = resolveTargetDimensions(src.width, src.height, aspect, currentScale);
  const baseName = sanitizeBaseName(src.originalName);
  const isIncreasing = targetBytes > src.sizeBytes;

  let outExt: 'png' | 'jpg' = 'jpg';
  let outMime = 'image/jpeg';
  let outPath = path.join(os.tmpdir(), `audit-resized-${crypto.randomUUID()}.jpg`);

  let resolvedAsPng = false;

  // Preserve PNG format when source is PNG and compressed PNG fits within targetBytes
  if (src.mimeType === 'image/png' && (isIncreasing || targetBytes >= src.sizeBytes * 0.5)) {
    const pngPath = path.join(os.tmpdir(), `audit-resized-${crypto.randomUUID()}.png`);
    const vf = buildCropScaleFilter(
      src.width,
      src.height,
      dims.targetW,
      dims.targetH,
      aspect
    );
    await runCommandBuffer('ffmpeg', [
      '-y',
      '-i',
      src.filePath,
      '-vf',
      vf,
      '-map_metadata',
      '-1',
      '-compression_level',
      '9',
      pngPath,
    ]);

    const pngStat = await fs.promises.stat(pngPath);
    if (pngStat.size <= targetBytes) {
      resolvedAsPng = true;
      outExt = 'png';
      outMime = 'image/png';
      outPath = pngPath;
      if (pngStat.size < targetBytes) {
        await padPngToTargetSize(outPath, targetBytes);
      }
    } else {
      await fs.promises.unlink(pngPath).catch(() => {});
    }
  }

  if (!resolvedAsPng) {
    // Encode JPEG at target quality and stay <= targetBytes (then top up to exact targetBytes)
    const minQ = quality === 'maximum' ? 1 : quality === 'high' ? 2 : 4;
    let matched = false;
    const maxScaleAttempts = targetBytes < 32 * 1024 ? 10 : 5;

    for (let scaleAttempt = 0; scaleAttempt < maxScaleAttempts && !matched; scaleAttempt++) {
      dims = resolveTargetDimensions(src.width, src.height, aspect, currentScale);
      const vf = buildCropScaleFilter(
        src.width,
        src.height,
        dims.targetW,
        dims.targetH,
        aspect
      );

      // Fast check at best allowed quality first
      await runCommandBuffer('ffmpeg', [
        '-y',
        '-i',
        src.filePath,
        '-vf',
        vf,
        '-map_metadata',
        '-1',
        '-q:v',
        String(minQ),
        outPath,
      ]);
      const bestQualStat = await fs.promises.stat(outPath);
      if (bestQualStat.size <= targetBytes) {
        matched = true;
        break;
      }

      // Binary search q:v between (minQ + 1)..31 to stay <= targetBytes with best possible quality
      let low = minQ + 1;
      let high = 31;
      let bestPassingQ = -1;
      for (let step = 0; step < 5 && low <= high; step++) {
        const midQ = Math.round((low + high) / 2);
        await runCommandBuffer('ffmpeg', [
          '-y',
          '-i',
          src.filePath,
          '-vf',
          vf,
          '-map_metadata',
          '-1',
          '-q:v',
          String(midQ),
          outPath,
        ]);
        const s = await fs.promises.stat(outPath);
        if (s.size <= targetBytes) {
          matched = true;
          bestPassingQ = midQ;
          high = midQ - 1;
        } else {
          low = midQ + 1;
        }
      }

      if (matched && bestPassingQ > 0) {
        // Re-render at bestPassingQ so outPath matches the winning pass
        await runCommandBuffer('ffmpeg', [
          '-y',
          '-i',
          src.filePath,
          '-vf',
          vf,
          '-map_metadata',
          '-1',
          '-q:v',
          String(bestPassingQ),
          outPath,
        ]);
        break;
      }

      if (!matched) {
        const nextScale = Math.max(2, Math.floor(currentScale * 0.68));
        if (nextScale === currentScale) break;
        currentScale = nextScale;
      }
    }

    if (!matched) {
      const vf = buildCropScaleFilter(
        src.width,
        src.height,
        dims.targetW,
        dims.targetH,
        aspect
      );
      await runCommandBuffer('ffmpeg', [
        '-y',
        '-i',
        src.filePath,
        '-vf',
        vf,
        '-map_metadata',
        '-1',
        '-q:v',
        '31',
        outPath,
      ]);
    }

    const statAfter = await fs.promises.stat(outPath);
    if (statAfter.size < targetBytes) {
      await padJpegToTargetSize(outPath, targetBytes);
    }
  }

  const finalStat = await fs.promises.stat(outPath);
  const outputFilename = `${baseName}-${dims.targetW}x${dims.targetH}.${outExt}`;
  const outToken = registerResizeOutputJob({
    filePath: outPath,
    filename: outputFilename,
    mimeType: outMime,
  });

  return {
    id: crypto.randomUUID(),
    kind: 'image',
    outputFilename,
    mimeType: outMime,
    width: dims.targetW,
    height: dims.targetH,
    aspectRatio: aspect,
    sizeBytes: finalStat.size,
    sizeKb: Number((finalStat.size / 1024).toFixed(2)),
    sizeMb: Number((finalStat.size / (1024 * 1024)).toFixed(3)),
    sizeLabel: formatBytes(finalStat.size),
    previewUrl: `/api/resize-preview?token=${outToken}`,
    downloadUrl: `/api/resize-download?token=${outToken}`,
  };
}

async function padMp4FreeAtom(filePath: string, targetBytes: number): Promise<void> {
  const stat = await fs.promises.stat(filePath);
  const needed = targetBytes - stat.size;
  if (needed < 16) return;

  // ISO BMFF 'free' box: 4-byte uint32BE total box size + 'free' + zero payload
  const fh = await fs.promises.open(filePath, 'a');
  try {
    const header = Buffer.alloc(8);
    header.writeUInt32BE(needed, 0);
    header.write('free', 4, 'ascii');
    await fh.write(header);

    let remaining = needed - 8;
    const chunk = Buffer.alloc(Math.min(remaining, 1024 * 1024), 0);
    while (remaining > 0) {
      const toWrite = Math.min(remaining, chunk.length);
      await fh.write(chunk, 0, toWrite);
      remaining -= toWrite;
    }
  } finally {
    await fh.close();
  }
}

async function resizeVideoToTarget(
  src: ResizeSourceJob,
  aspect: AspectRatioOption,
  scalePercent: number,
  audioClarity: number,
  targetBytesInput: number,
  quality: QualityPreset
): Promise<ResizedMediaResult> {
  const duration = Math.max(0.5, src.durationSeconds || 5);
  const targetBytes = Math.max(2 * 1024, Math.round(targetBytesInput));
  const isIncreasing = targetBytes > src.sizeBytes;

  let dims = resolveTargetDimensions(src.width, src.height, aspect, scalePercent);

  const targetTotalBps = Math.round((targetBytes * 8) / duration);
  if (!isIncreasing && scalePercent === 100) {
    if (targetTotalBps < 60_000 && dims.targetH > 128) {
      const ratio = dims.targetW / dims.targetH;
      dims = { targetW: evenDim(128 * ratio), targetH: 128 };
    } else if (targetTotalBps < 180_000 && dims.targetH > 240) {
      const ratio = dims.targetW / dims.targetH;
      dims = { targetW: evenDim(240 * ratio), targetH: 240 };
    } else if (targetTotalBps < 450_000 && dims.targetH > 480) {
      const ratio = dims.targetW / dims.targetH;
      dims = { targetW: evenDim(480 * ratio), targetH: 480 };
    }
  }

  let audioBps = 0;
  let keepAudio = src.hasAudio;
  if (src.hasAudio) {
    if (isIncreasing) {
      audioBps = quality === 'maximum' ? 256_000 : 192_000;
    } else if (targetTotalBps < 48_000) {
      keepAudio = false;
      audioBps = 0;
    } else if (targetTotalBps < 140_000) {
      audioBps = 32_000;
    } else if (targetTotalBps < 320_000) {
      audioBps = 64_000;
    } else if (targetTotalBps < 800_000) {
      audioBps = audioClarity > 0 ? 112_000 : 96_000;
    } else {
      audioBps = audioClarity > 0 ? 160_000 : 128_000;
    }
  }

  // Reserve ~4% for MP4 container overhead
  const usableTotalBps = Math.round(targetTotalBps * 0.96);
  const videoBps = Math.max(4_000, Math.min(45_000_000, usableTotalBps - audioBps));
  const lowFpsCap = !isIncreasing && targetBytes < 32 * 1024 ? 8 : !isIncreasing && targetBytes < 80 * 1024 ? 15 : 0;

  const vf = buildCropScaleFilter(
    src.width,
    src.height,
    dims.targetW,
    dims.targetH,
    aspect
  );
  const audioFilterChain = keepAudio ? buildVoiceEnhancementFilter(audioClarity) : null;
  const baseName = sanitizeBaseName(src.originalName);
  const outPath = path.join(os.tmpdir(), `audit-resized-${crypto.randomUUID()}.mp4`);

  const preset =
    quality === 'maximum' ? 'fast' : quality === 'high' ? 'veryfast' : 'ultrafast';

  const encodePass = async (targetVideoBps: number) => {
    const args = [
      '-y',
      '-i',
      src.filePath,
      '-vf',
      `${vf},format=yuv420p`,
    ];

    if (lowFpsCap > 0) {
      args.push('-r', String(lowFpsCap));
    }

    args.push(
      '-c:v',
      'libx264',
      '-preset',
      preset,
      '-b:v',
      String(targetVideoBps),
      '-maxrate',
      String(Math.round(targetVideoBps * 1.12)),
      '-bufsize',
      String(Math.round(targetVideoBps * 1.6))
    );

    if (keepAudio) {
      if (audioFilterChain) {
        args.push('-af', audioFilterChain);
      }
      args.push('-c:a', 'aac', '-b:a', String(audioBps));
    } else {
      args.push('-an');
    }

    args.push('-map_metadata', '-1', '-movflags', '+faststart', '-threads', '0', outPath);
    await runCommandBuffer('ffmpeg', args);
  };

  await encodePass(videoBps);

  const firstStat = await fs.promises.stat(outPath);
  if (firstStat.size > targetBytes) {
    const correctedBps = Math.max(
      3_000,
      Math.round(videoBps * (targetBytes / Math.max(1, firstStat.size)) * 0.92)
    );
    await encodePass(correctedBps);
  }

  const statAfterEncode = await fs.promises.stat(outPath);
  if (statAfterEncode.size < targetBytes) {
    await padMp4FreeAtom(outPath, targetBytes);
  }

  const finalStat = await fs.promises.stat(outPath);
  const outputFilename = `${baseName}-${dims.targetW}x${dims.targetH}.mp4`;
  const outToken = registerResizeOutputJob({
    filePath: outPath,
    filename: outputFilename,
    mimeType: 'video/mp4',
  });

  return {
    id: crypto.randomUUID(),
    kind: 'video',
    outputFilename,
    mimeType: 'video/mp4',
    width: dims.targetW,
    height: dims.targetH,
    aspectRatio: aspect,
    durationSeconds: src.durationSeconds,
    sizeBytes: finalStat.size,
    sizeKb: Number((finalStat.size / 1024).toFixed(2)),
    sizeMb: Number((finalStat.size / (1024 * 1024)).toFixed(3)),
    sizeLabel: formatBytes(finalStat.size),
    previewUrl: `/api/resize-preview?token=${outToken}`,
    downloadUrl: `/api/resize-download?token=${outToken}`,
  };
}

export async function processMediaResize(params: {
  uploadToken: string;
  aspectRatio: AspectRatioOption;
  scalePercent?: number;
  audioClarity?: number;
  targetKb?: number;
  targetMb?: number;
  quality: QualityPreset;
}): Promise<ResizedMediaResult> {
  const src = getResizeSourceJob(params.uploadToken);
  if (!src || !fs.existsSync(src.filePath)) {
    throw new Error('Your uploaded file session expired. Please upload the file again.');
  }

  const requestedKb =
    typeof params.targetKb === 'number' && Number.isFinite(params.targetKb) && params.targetKb > 0
      ? params.targetKb
      : (Number(params.targetMb) || 1) * 1024;

  const safeTargetBytes = Math.max(
    2 * 1024,
    Math.min(200 * 1024 * 1024, Math.round(requestedKb * 1024))
  );
  const safeScale = Math.max(10, Math.min(200, Number(params.scalePercent) || 100));
  const rawClarity = Number(params.audioClarity);
  const safeAudioClarity = Number.isFinite(rawClarity)
    ? Math.max(0, Math.min(100, Math.round(rawClarity)))
    : 0;

  if (src.kind === 'image') {
    return resizeImageToTarget(
      src,
      params.aspectRatio,
      safeScale,
      safeTargetBytes,
      params.quality
    );
  }
  return resizeVideoToTarget(
    src,
    params.aspectRatio,
    safeScale,
    safeAudioClarity,
    safeTargetBytes,
    params.quality
  );
}
